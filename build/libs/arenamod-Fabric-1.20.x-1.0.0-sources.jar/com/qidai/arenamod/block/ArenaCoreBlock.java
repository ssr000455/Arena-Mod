package com.qidai.arenamod.block;

import com.qidai.arenamod.game.GameManager;
import com.qidai.arenamod.network.ModNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3965;

public class ArenaCoreBlock extends class_2248 {
    public ArenaCoreBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (!world.field_9236 && player instanceof class_3222 serverPlayer) {
            // 检查玩家是否已经在游戏中
            if (GameManager.getInstance().isPlayerInGame(serverPlayer)) {
                return class_1269.field_5814;
            }
            // 发送打开模式选择界面的数据包
            ServerPlayNetworking.send(serverPlayer, ModNetworking.OPEN_MODE_SELECT_ID, PacketByteBufs.create());
        }
        return class_1269.field_5812;
    }
}
