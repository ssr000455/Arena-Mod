package com.qidai.arenamod.block;

import com.qidai.arenamod.ArenaMod;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.class_1747;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModBlocks {
    public static final class_2248 ARENA_CORE = register("arena_core",
            new ArenaCoreBlock(FabricBlockSettings.copyOf(class_2246.field_10327)
                    .method_22488()
                    .method_29292()
                    .method_9629(-1.0f, 3600000.0f))); // 不可破坏

    private static class_2248 register(String name, class_2248 block) {
        class_2960 id = new class_2960(ArenaMod.MOD_ID, name);
        class_2378.method_10230(class_7923.field_41175, id, block);
        class_2378.method_10230(class_7923.field_41178, id, new class_1747(block, new FabricItemSettings()));
        return block;
    }

    public static void register() {
        ArenaMod.LOGGER.info("注册方块");
    }
}
