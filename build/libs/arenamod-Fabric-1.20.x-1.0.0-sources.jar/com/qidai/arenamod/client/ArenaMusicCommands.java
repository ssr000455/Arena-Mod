package com.qidai.arenamod.client;

import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.class_124;
import net.minecraft.class_2561;

/**
 * 客户端音乐控制指令
 * /arena music next|previous|loop|order|random
 */
public class ArenaMusicCommands {

    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommandManager.literal("arena")
                    .then(ClientCommandManager.literal("music")
                            .then(ClientCommandManager.literal("next")
                                    .executes(ctx -> executeNext(ctx)))
                            .then(ClientCommandManager.literal("previous")
                                    .executes(ctx -> executePrevious(ctx)))
                            .then(ClientCommandManager.literal("loop")
                                    .executes(ctx -> executeLoop(ctx)))
                            .then(ClientCommandManager.literal("order")
                                    .executes(ctx -> executeOrder(ctx)))
                            .then(ClientCommandManager.literal("random")
                                    .executes(ctx -> executeRandom(ctx)))
                            .executes(ctx -> executeStatus(ctx))
                    )
            );
        });
    }

    private static int executeNext(CommandContext<FabricClientCommandSource> ctx) {
        ArenaMusicManager.nextTrack();
        ctx.getSource().sendFeedback(class_2561.method_43469("music.arenamod.next", ArenaMusicManager.getCurrentTrackName())
                .method_27692(class_124.field_1060));
        return 1;
    }

    private static int executePrevious(CommandContext<FabricClientCommandSource> ctx) {
        ArenaMusicManager.previousTrack();
        ctx.getSource().sendFeedback(class_2561.method_43469("music.arenamod.previous", ArenaMusicManager.getCurrentTrackName())
                .method_27692(class_124.field_1060));
        return 1;
    }

    private static int executeLoop(CommandContext<FabricClientCommandSource> ctx) {
        ArenaMusicManager.setPlayMode(ArenaMusicManager.PlayMode.LOOP);
        ctx.getSource().sendFeedback(class_2561.method_43471("music.arenamod.mode_loop").method_27692(class_124.field_1075));
        ctx.getSource().sendFeedback(class_2561.method_43469("music.arenamod.current", ArenaMusicManager.getCurrentTrackName())
                .method_27692(class_124.field_1080));
        return 1;
    }

    private static int executeOrder(CommandContext<FabricClientCommandSource> ctx) {
        ArenaMusicManager.setPlayMode(ArenaMusicManager.PlayMode.ORDER);
        ctx.getSource().sendFeedback(class_2561.method_43471("music.arenamod.mode_order").method_27692(class_124.field_1075));
        ctx.getSource().sendFeedback(class_2561.method_43469("music.arenamod.current", ArenaMusicManager.getCurrentTrackName())
                .method_27692(class_124.field_1080));
        return 1;
    }

    private static int executeRandom(CommandContext<FabricClientCommandSource> ctx) {
        ArenaMusicManager.setPlayMode(ArenaMusicManager.PlayMode.RANDOM);
        ctx.getSource().sendFeedback(class_2561.method_43471("music.arenamod.mode_random").method_27692(class_124.field_1075));
        ctx.getSource().sendFeedback(class_2561.method_43469("music.arenamod.current", ArenaMusicManager.getCurrentTrackName())
                .method_27692(class_124.field_1080));
        return 1;
    }

    private static int executeStatus(CommandContext<FabricClientCommandSource> ctx) {
        if (ArenaMusicManager.getMusicCount() == 0) {
            ctx.getSource().sendFeedback(class_2561.method_43471("music.arenamod.no_files").method_27692(class_124.field_1061));
            ctx.getSource().sendFeedback(class_2561.method_43471("music.arenamod.hint").method_27692(class_124.field_1080));
        }

        String modeName = switch (ArenaMusicManager.getPlayMode()) {
            case LOOP -> class_2561.method_43471("music.arenamod.mode_loop").getString();
            case ORDER -> class_2561.method_43471("music.arenamod.mode_order").getString();
            case RANDOM -> class_2561.method_43471("music.arenamod.mode_random").getString();
        };

        ctx.getSource().sendFeedback(class_2561.method_43471("music.arenamod.status_title").method_27692(class_124.field_1065));
        ctx.getSource().sendFeedback(class_2561.method_43469("music.arenamod.playing", (ArenaMusicManager.isPlaying() ?
                class_2561.method_43471("options.on") : class_2561.method_43471("options.off")).getString())
                .method_27692(class_124.field_1068));
        ctx.getSource().sendFeedback(class_2561.method_43469("music.arenamod.mode", modeName)
                .method_27692(class_124.field_1075));
        if (ArenaMusicManager.getMusicCount() > 0) {
            ctx.getSource().sendFeedback(class_2561.method_43469("music.arenamod.current", ArenaMusicManager.getCurrentTrackName())
                    .method_27692(class_124.field_1054));
        }
        ctx.getSource().sendFeedback(class_2561.method_43469("music.arenamod.tracks", ArenaMusicManager.getMusicCount())
                .method_27692(class_124.field_1080));
        if (!ArenaMusicManager.isAudioSystemAvailable()) {
            ctx.getSource().sendFeedback(class_2561.method_43471("music.arenamod.hint")
                    .method_27692(class_124.field_1080));
        }
        return 1;
    }
}
