package com.qidai.arenamod.mixin;

import com.qidai.arenamod.config.ArenaConfig;
import com.qidai.arenamod.dimension.ModDimensions;
import com.qidai.arenamod.game.GameInstance;
import com.qidai.arenamod.game.GameManager;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 追踪玩家在竞技场中放置的方块（用于 PVP 每5分钟清除）
 * 限制PVP模式方块放置上限为80个
 */
@Mixin(class_1747.class)
public class BlockPlacementMixin {

    @Inject(at = @At("HEAD"), method = "place", cancellable = true)
    private void onBeforePlace(class_1750 context, CallbackInfoReturnable<class_1269> cir) {
        var world = context.method_8045();
        if (world.field_9236) return;
        if (!world.method_27983().equals(ModDimensions.ARENA_WORLD_KEY)) return;

        if (context.method_8036() instanceof class_3222 player) {
            GameInstance game = GameManager.getInstance().getGame(player);
            if (game != null && game.isPVP()) {
                if (game.getPlacedBlocks().size() >= ArenaConfig.getInstance().getPvpMaxPlacedBlocks()) {
                    player.method_7353(class_2561.method_43469("message.arenamod.block_limit_reached", ArenaConfig.getInstance().getPvpMaxPlacedBlocks()).method_27692(class_124.field_1061), false);
                    cir.setReturnValue(class_1269.field_5814);
                }
            }
        }
    }

    @Inject(at = @At("RETURN"), method = "place")
    private void onPlace(class_1750 context, CallbackInfoReturnable<class_1269> cir) {
        if (cir.getReturnValue() != class_1269.field_5812) return;

        var world = context.method_8045();
        if (world.field_9236) return;
        if (!world.method_27983().equals(ModDimensions.ARENA_WORLD_KEY)) return;

        if (context.method_8036() instanceof class_3222 player) {
            GameInstance game = GameManager.getInstance().getGame(player);
            if (game != null && game.isPVP()) {
                class_2338 placedPos = context.method_8037();
                game.getPlacedBlocks().add(placedPos);
            }
        }
    }
}
