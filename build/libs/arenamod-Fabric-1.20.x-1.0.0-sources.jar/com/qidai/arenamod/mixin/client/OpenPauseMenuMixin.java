package com.qidai.arenamod.mixin.client;

import com.qidai.arenamod.dimension.ModDimensions;
import com.qidai.arenamod.screen.ArenaExitScreen;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 当玩家在竞技场维度时，将暂停菜单替换为退出确认界面
 */
@Mixin(class_310.class)
public class OpenPauseMenuMixin {

    @Inject(at = @At("HEAD"), method = "openPauseMenu", cancellable = true)
    private void onOpenPauseMenu(CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null && client.field_1687 != null) {
            if (client.field_1687.method_27983().equals(ModDimensions.ARENA_WORLD_KEY)) {
                client.method_1507(new ArenaExitScreen());
                ci.cancel();
            }
        }
    }
}
