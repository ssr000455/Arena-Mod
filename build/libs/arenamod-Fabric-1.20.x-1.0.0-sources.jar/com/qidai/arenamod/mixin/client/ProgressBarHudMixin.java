package com.qidai.arenamod.mixin.client;

import com.qidai.arenamod.client.ArenaMusicManager;
import com.qidai.arenamod.dimension.ModDimensions;
import com.qidai.arenamod.network.ModClientNetworking;
import com.qidai.arenamod.network.ModClientNetworking.GameProgressData;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 在屏幕顶部渲染竞技场进度条 + 驱动音乐播放
 */
@Mixin(class_329.class)
public class ProgressBarHudMixin {

    @Inject(at = @At("RETURN"), method = "render")
    private void onRenderHud(class_332 context, float tickDelta, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;

        boolean inArena = client.field_1687.method_27983().equals(ModDimensions.ARENA_WORLD_KEY);

        // 驱动音乐播放（检测维度变化控制启停）
        ArenaMusicManager.tick(inArena);

        if (!inArena) return;

        var progress = ModClientNetworking.currentProgress;
        if (progress == null) return;

        if (progress.isPVP()) {
            renderPvpHud(context, client, progress);
        } else {
            renderSinglePlayerHud(context, client, progress);
        }
    }

    private void renderSinglePlayerHud(class_332 context, class_310 client,
                                        ModClientNetworking.GameProgressData progress) {
        int screenWidth = client.method_22683().method_4486();
        int barWidth = 200;
        int barHeight = 8;
        int barX = (screenWidth - barWidth) / 2;
        int barY = 4;

        // 背景
        context.method_25294(barX - 1, barY - 1, barX + barWidth + 1, barY + barHeight + 1, 0xFF000000);
        context.method_25294(barX, barY, barX + barWidth, barY + barHeight, 0xFF333333);

        // 进度条
        int fillWidth = (int) (barWidth * progress.getProgress());
        if (fillWidth > 0) {
            int color = 0xFF00AA00;
            if (progress.currentBatch() >= progress.totalBatches() - 1) {
                color = 0xFFFFAA00;
            }
            context.method_25294(barX, barY, barX + fillWidth, barY + barHeight, color);
        }

        int textY = barY + barHeight + 2;

        // 波次信息
        context.method_51439(client.field_1772,
                class_2561.method_43471("hud.arenamod.wave").method_10852(class_2561.method_43470(": " + (progress.currentWave() + 1)))
                        .method_27695(class_124.field_1075, class_124.field_1067),
                barX, textY, 0xFFFFFFFF, true);

        // 批次信息
        context.method_51439(client.field_1772,
                class_2561.method_43471("hud.arenamod.batch").method_10852(class_2561.method_43470(": " + (progress.currentBatch() + 1) + "/" + progress.totalBatches()))
                        .method_27692(class_124.field_1068),
                barX + 80, textY, 0xFFFFFFFF, true);

        // 生命值
        if (progress.lives() > 0) {
            class_124 livesColor = progress.lives() <= 5 ? class_124.field_1061 : class_124.field_1060;
            context.method_51439(client.field_1772,
                    class_2561.method_43471("hud.arenamod.lives").method_10852(class_2561.method_43470(": " + progress.lives())).method_27695(livesColor, class_124.field_1067),
                    barX + 150, textY, 0xFFFFFFFF, true);
        }

        // EXP点数（右侧）
        String expStr = String.valueOf(progress.expPoints());
        class_2561 expText = class_2561.method_43471("hud.arenamod.exp").method_10852(class_2561.method_43470(": " + expStr)).method_27692(class_124.field_1054);
        context.method_51439(client.field_1772, expText,
                screenWidth - barX - client.field_1772.method_27525(expText), textY, 0xFFFFFFFF, true);
    }

    private void renderPvpHud(class_332 context, class_310 client,
                               ModClientNetworking.GameProgressData progress) {
        int screenWidth = client.method_22683().method_4486();
        int barWidth = 200;
        int barHeight = 10;
        int barX = (screenWidth - barWidth) / 2;
        int barY = 4;

        // 进度条背景
        context.method_25294(barX - 1, barY - 1, barX + barWidth + 1, barY + barHeight + 1, 0xFF000000);
        context.method_25294(barX, barY, barX + barWidth, barY + barHeight, 0xFF333333);

        // 时间进度条（从满到空）
        float timeProgress = progress.getPvpTimeProgress();
        int fillWidth = (int) (barWidth * (1f - timeProgress));
        if (fillWidth > 0) {
            int color;
            if (timeProgress < 0.5f) {
                color = 0xFF00CC00;       // 绿色
            } else if (timeProgress < 0.75f) {
                color = 0xFFCCCC00;       // 黄色
            } else {
                color = 0xFFCC0000;       // 红色
            }
            context.method_25294(barX, barY, barX + fillWidth, barY + barHeight, color);
        }

        int textY = barY + barHeight + 2;

        // 倒计时文字
        int remainingSec = progress.getPvpRemainingSeconds();
        String timeStr = String.format("%02d:%02d", remainingSec / 60, remainingSec % 60);
        class_124 timeColor = remainingSec > 120 ? class_124.field_1060 :
                (remainingSec > 60 ? class_124.field_1054 : class_124.field_1061);
        context.method_51439(client.field_1772,
                class_2561.method_43471("hud.arenamod.time").method_10852(class_2561.method_43470(": " + timeStr)).method_27695(timeColor, class_124.field_1067),
                barX, textY, 0xFFFFFFFF, true);

        // 存活人数（中间）
        String aliveStr = progress.pvpAliveCount() + "/" + progress.pvpTotalPlayerCount();
        class_2561 aliveText = class_2561.method_43471("hud.arenamod.alive").method_10852(class_2561.method_43470(": " + aliveStr)).method_27695(class_124.field_1068, class_124.field_1067);
        int aliveWidth = client.field_1772.method_27525(aliveText);
        context.method_51439(client.field_1772, aliveText,
                (screenWidth - aliveWidth) / 2, textY, 0xFFFFFFFF, true);

        // EXP（右侧）
        String expVal = String.valueOf(progress.expPoints());
        class_2561 expLabel = class_2561.method_43471("hud.arenamod.exp").method_10852(class_2561.method_43470(": " + expVal)).method_27692(class_124.field_1054);
        int expWidth = client.field_1772.method_27525(expLabel);
        context.method_51439(client.field_1772, expLabel,
                screenWidth - barX - expWidth, textY, 0xFFFFFFFF, true);

        // 第二行：奖杯数
        int textY2 = textY + 12;
        context.method_51439(client.field_1772,
                class_2561.method_43471("hud.arenamod.trophies").method_10852(class_2561.method_43470(": " + progress.lives())).method_27692(class_124.field_1065),
                barX, textY2, 0xFFFFFFFF, true);
    }
}
