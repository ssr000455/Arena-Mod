package com.qidai.arenamod.mixin;

import com.qidai.arenamod.config.ArenaConfig;
import com.qidai.arenamod.dimension.ModDimensions;
import com.qidai.arenamod.game.GameInstance;
import com.qidai.arenamod.game.GameManager;
import com.qidai.arenamod.item.ModItems;
import com.qidai.arenamod.wave.WaveSpawner;
import net.minecraft.class_124;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Entity death handler:
 * - Monster killed → grants EXP points per tracking table
 * - PvP kill → grants EXP + trophy (values from config)
 */
@Mixin(class_1309.class)
public class LivingEntityDeathMixin {

    @Inject(at = @At("HEAD"), method = "onDeath")
    private void onDeath(class_1282 source, CallbackInfo ci) {
        class_1309 entity = (class_1309) (Object) this;

        // 只在服务端竞技场维度中处理
        if (entity.method_37908().field_9236) return;
        if (!entity.method_37908().method_27983().equals(ModDimensions.ARENA_WORLD_KEY)) return;

        // 获取击杀者
        if (!(source.method_5529() instanceof class_3222 killer)) return;

        // ===== PvP kill: player kills another player =====
        if (entity instanceof class_3222 killedPlayer) {
            GameInstance game = GameManager.getInstance().getGame(killer);
            if (game != null && game.isPVP()) {
                int expOnKill = ArenaConfig.getInstance().getPvpExpOnKill();
                int trophyOnKill = ArenaConfig.getInstance().getPvpTrophyOnKill();
                if (expOnKill > 0) {
                    killer.method_31548().method_7398(new class_1799(ModItems.EXP_POINT, expOnKill));
                }
                game.addExpPoints(expOnKill);
                for (int t = 0; t < trophyOnKill; t++) game.addTrophy();

                killer.method_7353(class_2561.method_43469("message.arenamod.pvp_kill", expOnKill, trophyOnKill, game.getTrophyCount())
                        .method_27692(class_124.field_1065), false);
            }
            return;
        }

        // ===== 情况2: 击杀怪物 (单人/PVP通用) =====
        int expValue = WaveSpawner.getExpValue(entity.method_5667());
        if (expValue <= 0) return;

        // 给予经验点物品（直接进入背包）
        if (expValue > 0) {
            killer.method_31548().method_7398(new class_1799(ModItems.EXP_POINT, expValue));
        }

        // 更新游戏实例的 EXP 统计和杀敌数
        GameInstance game = GameManager.getInstance().getGame(killer);
        if (game != null) {
            game.addExpPoints(expValue);
            game.addKill();
        }

        // 清除 EXP 追踪
        WaveSpawner.removeTracking(entity.method_5667());
    }
}
