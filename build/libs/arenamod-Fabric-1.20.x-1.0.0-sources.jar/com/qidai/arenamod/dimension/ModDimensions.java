package com.qidai.arenamod.dimension;

import com.qidai.arenamod.ArenaMod;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public class ModDimensions {
    public static final class_5321<class_1937> ARENA_WORLD_KEY = class_5321.method_29179(
            class_7924.field_41223,
            new class_2960(ArenaMod.MOD_ID, "arena")
    );

    public static void register() {
        ArenaMod.LOGGER.info("注册维度: {}", ARENA_WORLD_KEY.method_29177());
    }
}
