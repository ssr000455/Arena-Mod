package com.qidai.arenamod.screen;

import com.qidai.arenamod.game.MerchantData;
import com.qidai.arenamod.network.ModClientNetworking;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * 商人交易界面（支持物品商人和方块商人）
 */
public class MerchantScreen extends class_437 {
    private static final int BUTTON_WIDTH = 160;
    private static final int BUTTON_HEIGHT = 20;
    private static final int START_Y = 40;
    private static final int ROW_HEIGHT = 24;

    private final int tier;
    private final boolean upgradeAvailable;
    private final int merchantType;
    private final List<MerchantData.MerchantItem> items;
    private int scrollOffset = 0;
    private int maxScroll = 0;

    public MerchantScreen(int tier, boolean upgradeAvailable) {
        this(tier, upgradeAvailable, MerchantData.MERCHANT_TYPE_ITEM);
    }

    public MerchantScreen(int tier, boolean upgradeAvailable, int merchantType) {
        super(class_2561.method_43469("screen.arenamod.merchant.title",
                class_2561.method_43471(MerchantData.getMerchantName(merchantType)), tier));
        this.tier = tier;
        this.upgradeAvailable = upgradeAvailable;
        this.merchantType = merchantType;
        this.items = new ArrayList<>(MerchantData.getItemsForMerchant(merchantType, tier));
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        int centerX = this.field_22789 / 2;
        int currentY = START_Y;

        String currentCategory = "";
        int index = 0;

        for (MerchantData.MerchantItem item : items) {
            // 分类标题
            if (!item.category().equals(currentCategory)) {
                currentCategory = item.category();
                currentY += 6;
                method_37063(class_4185.method_46430(
                        class_2561.method_43469("merchant.arenamod.entry",
                                class_2561.method_43471(MerchantData.getCategoryName(currentCategory)))
                                .method_10852(class_2561.method_43469("merchant.arenamod.entry_cost", item.expCost())),
                        button -> {}
                ).method_46434(centerX - 150, currentY, 300, 16).method_46431());
                currentY += 20;
            }

            // 商品按钮
            int finalIndex = index;
            class_2561 itemName = item.item().method_7964();
            int count = item.item().method_7947();
            class_2561 buttonText = count > 1
                    ? class_2561.method_43470("").method_10852(itemName).method_10852(class_2561.method_43470(" x" + count + " — " + item.expCost() + " EXP"))
                    : class_2561.method_43470("").method_10852(itemName).method_10852(class_2561.method_43470(" — " + item.expCost() + " EXP"));
            method_37063(class_4185.method_46430(
                    buttonText,
                    button -> {
                        ModClientNetworking.sendMerchantBuy(finalIndex, merchantType);
                        field_22787.method_1507(null);
                    }
            ).method_46434(centerX - 80, currentY, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());

            currentY += ROW_HEIGHT;
            index++;
        }

        // 升级按钮
        if (upgradeAvailable) {
            currentY += 10;
            int upgradeCost = MerchantData.getUpgradeCost(tier);
            String targetTier = class_2561.method_43471("merchant.arenamod.tier." + (tier + 1)).getString();
            method_37063(class_4185.method_46430(
                    class_2561.method_43469("merchant.arenamod.upgrade", targetTier, upgradeCost),
                    button -> {
                        ModClientNetworking.sendMerchantBuy(-1, merchantType);
                        field_22787.method_1507(null);
                    }
            ).method_46434(centerX - 80, currentY, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());
        }

        maxScroll = Math.max(0, currentY - this.field_22790 + 20);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double amount) {
        int oldScroll = scrollOffset;
        scrollOffset = (int) Math.max(0, Math.min(maxScroll, scrollOffset - amount * 20));
        int delta = scrollOffset - oldScroll;
        for (var widget : this.method_25396()) {
            if (widget instanceof net.minecraft.class_339 clickable) {
                clickable.method_46419(clickable.method_46427() - delta);
            }
        }
        return true;
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
