package com.qidai.arenamod.screen;

import com.qidai.arenamod.network.ModClientNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * 模式选择界面 - 玩家选择单人模式或PVP模式
 */
public class ModeSelectScreen extends class_437 {
    private static final int BUTTON_WIDTH = 200;
    private static final int BUTTON_HEIGHT = 40;
    private static final int BUTTON_SPACING = 10;
    private boolean modeSent = false;

    public ModeSelectScreen() {
        super(class_2561.method_43471("screen.arenamod.mode_select"));
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        int centerX = field_22789 / 2;
        int startY = field_22790 / 2 - BUTTON_HEIGHT - BUTTON_SPACING / 2;

        // 单人模式按钮
        method_37063(class_4185.method_46430(
                class_2561.method_43471("screen.arenamod.mode_select.single"),
                button -> sendMode(0)
        ).method_46434(centerX - BUTTON_WIDTH / 2, startY, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());

        // PVP模式按钮
        method_37063(class_4185.method_46430(
                class_2561.method_43471("screen.arenamod.mode_select.pvp"),
                button -> sendMode(1)
        ).method_46434(centerX - BUTTON_WIDTH / 2, startY + BUTTON_HEIGHT + BUTTON_SPACING, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());
    }

    private void sendMode(int mode) {
        if (modeSent) return;
        modeSent = true;
        ModClientNetworking.sendModeSelection(mode);
        method_25419();
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public boolean method_25422() {
        return true;
    }
}
