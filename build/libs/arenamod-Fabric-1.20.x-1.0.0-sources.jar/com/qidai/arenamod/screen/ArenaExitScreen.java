package com.qidai.arenamod.screen;

import com.qidai.arenamod.network.ModNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * 竞技场退出确认界面 - 保存并退出 / 保存并断开 / 继续游戏
 */
public class ArenaExitScreen extends class_437 {
    private static final int BUTTON_WIDTH = 220;
    private static final int BUTTON_HEIGHT = 40;

    public ArenaExitScreen() {
        super(class_2561.method_43471("screen.arenamod.exit_title"));
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        int centerX = field_22789 / 2;
        int startY = field_22790 / 2 - BUTTON_HEIGHT - 15;

        // 保存并退出（回到主世界继续玩）
        method_37063(class_4185.method_46430(
                class_2561.method_43471("screen.arenamod.exit_save"),
                button -> {
                    ClientPlayNetworking.send(ModNetworking.SAVE_EXIT_ID, PacketByteBufs.create());
                    method_25419();
                }
        ).method_46434(centerX - BUTTON_WIDTH / 2, startY, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());

        // 保存并返回主菜单（断开连接）
        method_37063(class_4185.method_46430(
                class_2561.method_43471("screen.arenamod.exit_disconnect"),
                button -> {
                    ClientPlayNetworking.send(ModNetworking.SAVE_EXIT_DISCONNECT_ID, PacketByteBufs.create());
                    class_310 client = class_310.method_1551();
                    if (client.method_1562() != null) {
                        client.method_1562().method_48296().method_10747(
                                class_2561.method_43471("screen.arenamod.exit_disconnected"));
                    }
                }
        ).method_46434(centerX - BUTTON_WIDTH / 2, startY + BUTTON_HEIGHT + 5, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());

        // 继续游戏
        method_37063(class_4185.method_46430(
                class_2561.method_43471("screen.arenamod.exit_continue"),
                button -> method_25419()
        ).method_46434(centerX - BUTTON_WIDTH / 2, startY + (BUTTON_HEIGHT + 5) * 2, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());
    }

    @Override
    public boolean method_25421() {
        return true;
    }

    @Override
    public boolean method_25422() {
        return true;
    }
}
