package com.qidai.arenamod.item;

import com.qidai.arenamod.ArenaMod;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModItems {
    public static final class_1792 EXP_POINT = register("exp_point",
            new class_1792(new FabricItemSettings().method_7889(9999).method_7894(class_1814.field_8907)));

    private static class_1792 register(String name, class_1792 item) {
        class_2960 id = new class_2960(ArenaMod.MOD_ID, name);
        return class_2378.method_10230(class_7923.field_41178, id, item);
    }

    public static void register() {
        ArenaMod.LOGGER.info("注册物品");
    }
}
