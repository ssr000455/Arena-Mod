package com.qidai.arenamod.item;

import com.qidai.arenamod.ArenaMod;
import com.qidai.arenamod.block.ModBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModItemGroup {
    public static final class_1761 ARENA_GROUP = FabricItemGroup.builder()
            .method_47320(() -> new class_1799(ModItems.EXP_POINT))
            .method_47321(class_2561.method_43471("itemGroup.arenamod.arena_core"))
            .method_47317((context, entries) -> {
                entries.method_45421(ModBlocks.ARENA_CORE);
                entries.method_45421(ModItems.EXP_POINT);
            })
            .method_47324();

    public static void register() {
        class_2378.method_10230(class_7923.field_44687,
                new class_2960(ArenaMod.MOD_ID, "arena_group"),
                ARENA_GROUP);
        ArenaMod.LOGGER.info("注册创造模式标签页");
    }
}
