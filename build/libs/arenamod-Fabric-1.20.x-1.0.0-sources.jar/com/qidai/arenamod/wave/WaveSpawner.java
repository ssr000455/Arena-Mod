package com.qidai.arenamod.wave;

import com.qidai.arenamod.game.GameInstance;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1308;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

/**
 * 波次刷怪器 - 负责在竞技场内生成怪物并追踪 EXP
 */
public class WaveSpawner {
    private static final Random RANDOM = new Random();
    private static final int MIN_SPAWN_DISTANCE = 10;

    // UUID → EXP 值追踪表（用于怪物死亡时发放经验点）
    private static final Map<UUID, Integer> EXP_TRACKER = new ConcurrentHashMap<>();

    /**
     * 生成指定批次的所有怪物
     */
    public static List<class_1308> spawnBatch(class_3218 world, GameInstance game, WaveDefinition.Batch batch) {
        List<class_1308> spawned = new ArrayList<>();
        int arenaHalf = game.getArenaHalf();

        for (WaveDefinition.SpawnGroup group : batch.groups()) {
            for (char code : group.codes()) {
                int count = group.countPerCode();
                MonsterCodes.MonsterEntry entry = MonsterCodes.get(code);
                int exp = entry.expPoints();
                for (int i = 0; i < count; i++) {
                    class_2338 spawnPos = findSpawnPosition(world, game.getArenaCenter(), arenaHalf);
                    if (spawnPos != null) {
                        class_1308 entity = entry.create(world, spawnPos);
                        if (entity != null) {
                            // 设置婴儿僵尸
                            if (code == 'S' && entity instanceof net.minecraft.class_1642 zombie) {
                                zombie.method_7217(true);
                            }
                            world.method_8649(entity);
                            // 追踪 EXP
                            EXP_TRACKER.put(entity.method_5667(), exp);
                            spawned.add(entity);
                        }
                    }
                }
            }
        }
        return spawned;
    }

    /**
     * 获取怪物对应的 EXP 值
     */
    public static int getExpValue(UUID entityUuid) {
        return EXP_TRACKER.getOrDefault(entityUuid, 0);
    }

    /**
     * 移除 EXP 追踪（怪物已死亡或游戏结束）
     */
    public static void removeTracking(UUID entityUuid) {
        EXP_TRACKER.remove(entityUuid);
    }

    /**
     * 清除所有追踪（游戏结束）
     */
    public static void clearAllTracking() {
        EXP_TRACKER.clear();
    }

    private static class_2338 findSpawnPosition(class_3218 world, class_2338 center, int arenaHalf) {
        for (int attempt = 0; attempt < 20; attempt++) {
            int x = center.method_10263() + RANDOM.nextInt(arenaHalf * 2) - arenaHalf;
            int z = center.method_10260() + RANDOM.nextInt(arenaHalf * 2) - arenaHalf;

            double dist = Math.sqrt(Math.pow(x - center.method_10263(), 2) + Math.pow(z - center.method_10260(), 2));
            if (dist < MIN_SPAWN_DISTANCE) continue;

            int y = center.method_10264();
            class_2338 pos = new class_2338(x, y, z);

            if (world.method_8320(pos).method_26215() && !world.method_8320(pos.method_10074()).method_26215()) {
                return pos;
            }
            for (int dy = 1; dy <= 3; dy++) {
                class_2338 checkPos = pos.method_10086(dy);
                if (world.method_8320(checkPos).method_26215() && !world.method_8320(checkPos.method_10074()).method_26215()) {
                    return checkPos;
                }
            }
        }
        // 保底：在中心附近寻找一个安全位置
        for (int attempt = 0; attempt < 10; attempt++) {
            class_2338 fallbackPos = center.method_10069(
                    RANDOM.nextInt(arenaHalf * 2) - arenaHalf, 0,
                    RANDOM.nextInt(arenaHalf * 2) - arenaHalf
            ).method_10086(1);
            if (world.method_8320(fallbackPos).method_26215()) {
                return fallbackPos;
            }
        }
        return center.method_10086(1);
    }

    public static boolean isBatchCleared(List<class_1308> currentBatchMobs) {
        return currentBatchMobs.stream().allMatch(m -> !m.method_5805());
    }
}
