package com.qidai.arenamod.wave;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3730;

/**
 * 怪物代号映射表 + 经验点数值
 */
public class MonsterCodes {
    private static final Map<Character, MonsterEntry> CODE_MAP = new HashMap<>();

    public record MonsterEntry(class_1299<? extends class_1308> type, String name, int expPoints) {
        public class_1308 create(class_3218 world, class_2338 pos) {
            class_1308 entity = (class_1308) type.method_5888(world, null, null, pos, class_3730.field_16462, false, false);
            if (entity != null) {
                entity.method_23327(pos.method_10263() + 0.5, pos.method_10264(), pos.method_10260() + 0.5);
                entity.method_5971();
            }
            return entity;
        }
    }

    static {
        // ===== 普通（1点）=====
        map('A', class_1299.field_6051, "僵尸", 1);
        map('B', class_1299.field_6137, "小白", 1);
        map('C', class_1299.field_6046, "苦力怕", 1);
        map('D', class_1299.field_6079, "蜘蛛", 1);
        map('F', class_1299.field_6091, "末影人", 1);
        map('H', class_1299.field_6059, "怨灵", 1);
        map('I', class_1299.field_6117, "掠夺者(斧)", 1);
        map('J', class_1299.field_6105, "掠夺者(弩)", 1);
        map('K', class_1299.field_6102, "岩浆怪", 1);
        map('L', class_1299.field_6050, "下界猪兽", 2);
        map('M', class_1299.field_6054, "僵尸猎人", 1);
        map('N', class_1299.field_6123, "溺尸", 1);
        map('O', class_1299.field_6105, "掠夺者队长", 1);
        map('S', class_1299.field_6051, "小僵尸", 1);  // 婴儿僵尸在 spawn 时设置
        map('T', class_1299.field_6071, "尸壳", 1);
        map('U', class_1299.field_6109, "潜伏影怪", 1);
        map('V', class_1299.field_6078, "幻翼", 1);
        map('W', class_1299.field_6084, "洞穴蜘蛛", 1);
        map('X', class_1299.field_6079, "蜘蛛", 1);
        map('Z', class_1299.field_6069, "史莱姆", 1);
        map('ǔ', class_1299.field_6128, "末影螨", 1);
        map('△', class_1299.field_6145, "女巫", 1);
        map('☆', class_1299.field_6076, "凋零小白", 1);
        map('◍', class_1299.field_6125, "蠹虫", 1);

        // ===== 强力（2点）=====
        map('P', class_1299.field_6134, "劫掠兽", 2);
        map('Q', class_1299.field_6090, "尖刺法师", 2);
        map('◙', class_1299.field_6090, "幻魔者", 2);
        map('◇', class_1299.field_6107, "恶魂", 2);

        // ===== 极强（3点）=====
        map('G', class_1299.field_6116, "末影龙", 3);
        map('E', class_1299.field_38095, "寻声守卫者", 3);
        map('Y', class_1299.field_6119, "凋灵", 3);
        map('R', class_1299.field_6076, "凋零", 3);
    }

    private static void map(char code, class_1299<?> type, String name, int exp) {
        CODE_MAP.put(code, new MonsterEntry((class_1299<? extends class_1308>) type, name, exp));
    }

    public static MonsterEntry get(char code) {
        MonsterEntry entry = CODE_MAP.get(code);
        if (entry == null) {
            throw new IllegalArgumentException("未知的怪物代号: " + code);
        }
        return entry;
    }

    public static boolean isValid(char code) {
        return CODE_MAP.containsKey(code);
    }

    public static int getExpPoints(char code) {
        MonsterEntry entry = CODE_MAP.get(code);
        return entry != null ? entry.expPoints() : 0;
    }
}
