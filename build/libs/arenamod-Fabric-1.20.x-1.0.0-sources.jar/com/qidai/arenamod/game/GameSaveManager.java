package com.qidai.arenamod.game;

import com.qidai.arenamod.ArenaMod;
import net.minecraft.class_2487;
import net.minecraft.class_2507;
import net.minecraft.class_5218;
import net.minecraft.server.MinecraftServer;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;

/**
 * 游戏存档管理器 - 保存/读取玩家游戏进度（含经验点）
 */
public class GameSaveManager {
    private static GameSaveManager INSTANCE;

    private GameSaveManager() {}

    public static GameSaveManager getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new GameSaveManager();
        }
        return INSTANCE;
    }

    private Path getSaveDir(MinecraftServer server) {
        Path worldDir = server.method_27050(class_5218.field_24188);
        Path saveDir = worldDir.resolve("arenamod").resolve("saves");
        try {
            Files.createDirectories(saveDir);
        } catch (IOException e) {
            ArenaMod.LOGGER.error("无法创建存档目录", e);
        }
        return saveDir;
    }

    private Path getSaveFile(MinecraftServer server, UUID playerUuid) {
        return getSaveDir(server).resolve(playerUuid.toString() + ".dat");
    }

    /**
     * 保存游戏进度
     */
    public void saveGame(MinecraftServer server, GameInstance game) {
        Path saveFile = getSaveFile(server, game.getPlayerUuid());

        class_2487 nbt = new class_2487();
        nbt.method_10569("waveIndex", game.getCurrentWaveIndex());
        nbt.method_10569("batchIndex", game.getCurrentBatchIndex());
        nbt.method_10569("arenaCenterX", game.getArenaCenter().method_10263());
        nbt.method_10569("arenaCenterY", game.getArenaCenter().method_10264());
        nbt.method_10569("arenaCenterZ", game.getArenaCenter().method_10260());
        nbt.method_10582("gameMode", game.getGameMode().name());
        nbt.method_10544("elapsedTime", game.getElapsedTime());
        nbt.method_10569("expPoints", game.getTotalExpPoints());
        nbt.method_10569("trophyCount", game.getTrophyCount());
        nbt.method_10569("passCount", game.getPassCount());
        nbt.method_10569("blockMerchantTier", game.getBlockMerchantTier());
        nbt.method_10569("potionMerchantTier", game.getPotionMerchantTier());
        nbt.method_10569("lives", game.getLives());
        nbt.method_10569("cycleCount", game.getCycleCount());

        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(saveFile.toFile()))) {
            class_2507.method_10628(nbt, dos);
            ArenaMod.LOGGER.info("游戏进度已保存: {}", saveFile);
        } catch (IOException e) {
            ArenaMod.LOGGER.error("保存游戏进度失败", e);
        }
    }

    /**
     * 读取游戏进度
     */
    public GameSaveData loadGame(MinecraftServer server, UUID playerUuid) {
        Path saveFile = getSaveFile(server, playerUuid);
        if (!Files.exists(saveFile)) {
            return null;
        }

        try (DataInputStream dis = new DataInputStream(new FileInputStream(saveFile.toFile()))) {
            class_2487 nbt = class_2507.method_10627(dis);
            if (nbt == null) return null;

            int waveIndex = nbt.method_10550("waveIndex");
            int batchIndex = nbt.method_10550("batchIndex");
            int centerX = nbt.method_10550("arenaCenterX");
            int centerY = nbt.method_10550("arenaCenterY");
            int centerZ = nbt.method_10550("arenaCenterZ");
            String mode = nbt.method_10558("gameMode");
            long elapsed = nbt.method_10537("elapsedTime");
            int expPoints = nbt.method_10550("expPoints");
            int trophyCount = nbt.method_10550("trophyCount");
            int passCount = nbt.method_10550("passCount");
            int blockMerchantTier = nbt.method_10550("blockMerchantTier");
            int potionMerchantTier = nbt.method_10550("potionMerchantTier");
            int lives = nbt.method_10550("lives");
            int cycleCount = nbt.method_10550("cycleCount");

            return new GameSaveData(waveIndex, batchIndex,
                    new net.minecraft.class_2338(centerX, centerY, centerZ),
                    GameMode.valueOf(mode), elapsed, expPoints, trophyCount, passCount, blockMerchantTier, potionMerchantTier, lives, cycleCount);
        } catch (IOException e) {
            ArenaMod.LOGGER.error("读取游戏进度失败", e);
            return null;
        }
    }

    public void deleteSave(MinecraftServer server, UUID playerUuid) {
        Path saveFile = getSaveFile(server, playerUuid);
        try {
            Files.deleteIfExists(saveFile);
        } catch (IOException e) {
            ArenaMod.LOGGER.error("删除存档失败", e);
        }
    }

    public boolean hasSave(MinecraftServer server, UUID playerUuid) {
        return Files.exists(getSaveFile(server, playerUuid));
    }

    // ===== 奖杯持久化（独立于游戏会话） =====

    private Path getTrophyDir(MinecraftServer server) {
        Path worldDir = server.method_27050(class_5218.field_24188);
        Path trophyDir = worldDir.resolve("arenamod").resolve("trophies");
        try {
            Files.createDirectories(trophyDir);
        } catch (IOException e) {
            ArenaMod.LOGGER.error("无法创建奖杯目录", e);
        }
        return trophyDir;
    }

    private Path getTrophyFile(MinecraftServer server, UUID playerUuid) {
        return getTrophyDir(server).resolve(playerUuid.toString() + ".dat");
    }

    /**
     * 读取玩家奖杯数
     */
    public int loadTrophyCount(MinecraftServer server, UUID playerUuid) {
        Path file = getTrophyFile(server, playerUuid);
        if (!Files.exists(file)) return 0;

        try (DataInputStream dis = new DataInputStream(new FileInputStream(file.toFile()))) {
            class_2487 nbt = class_2507.method_10627(dis);
            if (nbt == null) return 0;
            return nbt.method_10550("trophyCount");
        } catch (IOException e) {
            ArenaMod.LOGGER.error("读取奖杯数据失败", e);
            return 0;
        }
    }

    /**
     * 保存玩家奖杯数
     */
    public void saveTrophyCount(MinecraftServer server, UUID playerUuid, int count) {
        Path file = getTrophyFile(server, playerUuid);

        class_2487 nbt = new class_2487();
        nbt.method_10569("trophyCount", count);

        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream(file.toFile()))) {
            class_2507.method_10628(nbt, dos);
        } catch (IOException e) {
            ArenaMod.LOGGER.error("保存奖杯数据失败", e);
        }
    }

    /**
     * 增加玩家奖杯数并保存
     */
    public void addTrophyCount(MinecraftServer server, UUID playerUuid, int amount) {
        int current = loadTrophyCount(server, playerUuid);
        saveTrophyCount(server, playerUuid, current + amount);
    }

    public record GameSaveData(
            int waveIndex,
            int batchIndex,
            net.minecraft.class_2338 arenaCenter,
            GameMode gameMode,
            long elapsedTime,
            int expPoints,
            int trophyCount,
            int passCount,
            int blockMerchantTier,
            int potionMerchantTier,
            int lives,
            int cycleCount
    ) {}
}
