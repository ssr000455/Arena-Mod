package com.qidai.arenamod.game;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2287;
import net.minecraft.class_2290;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_7157;
import com.qidai.arenamod.item.ModItems;
import java.util.Collection;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class ModCommands {

    public static void register() {
        CommandRegistrationCallback.EVENT.register(ModCommands::registerCommands);
    }

    private static void registerCommands(CommandDispatcher<class_2168> dispatcher,
                                          class_7157 registryAccess,
                                          class_2170.class_5364 environment) {
        dispatcher.register(method_9247("arena")
                .then(method_9247("resume")
                        .executes(ModCommands::resumeGame))
                .then(method_9247("new")
                        .executes(ModCommands::newGame))
                .then(method_9247("trophy")
                        .then(method_9247("exchange")
                                .then(method_9244("item", class_2287.method_9776(registryAccess))
                                        .then(method_9244("amount", IntegerArgumentType.integer(0, 128))
                                                .executes(ModCommands::exchangeTrophy)))))
                .then(method_9247("clearblocks")
                        .executes(ModCommands::clearPlayerBlocks))
                .then(method_9247("individual")
                        .then(method_9244("key", StringArgumentType.word())
                                .executes(ModCommands::spawnMerchants)))
                .then(method_9247("life")
                        .executes(ModCommands::buyLife))
                // 管理员指令（需要 OP）
                .then(method_9247("admin")
                        .requires(source -> source.method_9259(2))
                        .then(method_9247("setexp")
                                .then(method_9244("targets", class_2186.method_9308())
                                        .then(method_9244("amount", IntegerArgumentType.integer(0, 99999))
                                                .executes(ModCommands::adminSetExp))))
                        .then(method_9247("settrophy")
                                .then(method_9244("targets", class_2186.method_9308())
                                        .then(method_9244("amount", IntegerArgumentType.integer(0, 99999))
                                                .executes(ModCommands::adminSetTrophy)))))

        );
    }

    private static int resumeGame(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43471("message.arenamod.player_only_command"));
            return 0;
        }

        GameSaveManager.GameSaveData saveData = GameSaveManager.getInstance().loadGame(
                player.method_5682(), player.method_5667());
        if (saveData == null) {
            player.method_7353(class_2561.method_43471("message.arenamod.save_not_found").method_27692(class_124.field_1061), false);
            return 0;
        }

        GameManager.getInstance().resumeGame(player, saveData);
        return 1;
    }

    private static int newGame(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43471("message.arenamod.player_only_command"));
            return 0;
        }

        GameSaveManager.getInstance().deleteSave(player.method_5682(), player.method_5667());
        player.method_7353(class_2561.method_43471("message.arenamod.save_deleted").method_27692(class_124.field_1060), false);
        return 1;
    }

    private static int exchangeTrophy(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43471("message.arenamod.player_only_command"));
            return 0;
        }

        class_2290 itemArg = class_2287.method_9777(ctx, "item");
        int amount = IntegerArgumentType.getInteger(ctx, "amount");

        // 检查奖杯数
        int trophyCount = GameSaveManager.getInstance().loadTrophyCount(player.method_5682(), player.method_5667());
        if (trophyCount < 1) {
            player.method_7353(class_2561.method_43471("message.arenamod.trophies_not_enough").method_27692(class_124.field_1061), false);
            return 0;
        }

        // 扣除 1 奖杯
        GameSaveManager.getInstance().saveTrophyCount(player.method_5682(), player.method_5667(), trophyCount - 1);

        // 发放物品（拆分为多个符合堆叠上限的 ItemStack）
        String itemName = class_2561.method_43471("message.arenamod.unknown_item").getString();
        try {
            if (amount > 0) {
                class_1799 single = itemArg.method_9781(1, false);
                itemName = single.method_7909().method_7848().getString();
                int maxStack = single.method_7914();
                int remaining = amount;
                while (remaining > 0) {
                    int batchSize = Math.min(remaining, maxStack);
                    player.method_31548().method_7398(itemArg.method_9781(batchSize, false));
                    remaining -= batchSize;
                }
            } else {
                class_1799 single = itemArg.method_9781(1, false);
                itemName = single.method_7909().method_7848().getString();
            }
        } catch (CommandSyntaxException e) {
            player.method_7353(class_2561.method_43471("message.arenamod.item_data_invalid").method_27692(class_124.field_1061), false);
            return 0;
        }

        player.method_7353(class_2561.method_43469("message.arenamod.trophy_exchange", amount, itemName)
                .method_27692(class_124.field_1060), false);
        return 1;
    }

    private static int clearPlayerBlocks(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43471("message.arenamod.player_only_command"));
            return 0;
        }

        GameInstance game = GameManager.getInstance().getGame(player);
        if (game == null) {
            player.method_7353(class_2561.method_43471("message.arenamod.not_in_game").method_27692(class_124.field_1061), false);
            return 0;
        }

        if (!(player.method_37908() instanceof class_3218 serverWorld)) {
            player.method_7353(class_2561.method_43471("message.arenamod.server_world_only").method_27692(class_124.field_1061), false);
            return 0;
        }

        // 清除竞技场内所有非结构性方块
        ArenaBuilder.clearNonStructuralBlocks(serverWorld, game.getArenaCenter(),
                game.getArenaHalf(), game.getArenaHeight());

        // 如果是PVP模式，同时清空放置记录
        if (game.isPVP()) {
            game.getPlacedBlocks().clear();
        }

        player.method_7353(class_2561.method_43471("message.arenamod.blocks_cleared").method_27692(class_124.field_1060), false);
        return 1;
    }

    private static int spawnMerchants(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43471("message.arenamod.player_only_command"));
            return 0;
        }

        String key = StringArgumentType.getString(ctx, "key");
        if (!"114514".equals(key)) {
            player.method_7353(class_2561.method_43471("message.arenamod.invalid_key").method_27692(class_124.field_1061), false);
            return 0;
        }

        GameManager.getInstance().spawnPlayerMerchants(player);
        return 1;
    }

    private static int buyLife(CommandContext<class_2168> ctx) {
        class_2168 source = ctx.getSource();
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43471("message.arenamod.player_only_command"));
            return 0;
        }

        GameInstance game = GameManager.getInstance().getGame(player);
        if (game == null || game.getGameMode() != GameMode.SINGLE_PLAYER) {
            player.method_7353(class_2561.method_43471("message.arenamod.not_in_single_player").method_27692(class_124.field_1061), false);
            return 0;
        }

        // 统计经验点
        int expCount = 0;
        for (int i = 0; i < player.method_31548().method_5439(); i++) {
            class_1799 stack = player.method_31548().method_5438(i);
            if (stack.method_31574(ModItems.EXP_POINT)) {
                expCount += stack.method_7947();
            }
        }

        if (expCount < 80) {
            player.method_7353(class_2561.method_43471("message.arenamod.exp_not_enough_life").method_27692(class_124.field_1061), false);
            return 0;
        }

        // 扣除80经验
        int toRemove = 80;
        for (int i = 0; i < player.method_31548().method_5439() && toRemove > 0; i++) {
            class_1799 stack = player.method_31548().method_5438(i);
            if (stack.method_31574(ModItems.EXP_POINT)) {
                int removed = Math.min(toRemove, stack.method_7947());
                stack.method_7934(removed);
                toRemove -= removed;
            }
        }
        game.addExpPoints(-80);

        // 加一条命
        game.addLife();

        player.method_7353(class_2561.method_43469("message.arenamod.life_exchanged", game.getLives())
                .method_27692(class_124.field_1060), false);
        return 1;
    }

    // ===== 管理员指令 =====

    /** /arena admin setexp <targets> <amount> - 设置玩家经验点数量 */
    private static int adminSetExp(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        Collection<class_3222> targets = class_2186.method_9312(ctx, "targets");
        int amount = IntegerArgumentType.getInteger(ctx, "amount");

        class_1799 expStack = new class_1799(ModItems.EXP_POINT, amount);
        for (class_3222 target : targets) {
            // 清空原有经验点
            for (int i = 0; i < target.method_31548().method_5439(); i++) {
                class_1799 stack = target.method_31548().method_5438(i);
                if (stack.method_31574(ModItems.EXP_POINT)) {
                    target.method_31548().method_5447(i, class_1799.field_8037);
                }
            }
            // 发放新经验点
            target.method_31548().method_7398(expStack.method_7972());
            target.method_7353(class_2561.method_43469("message.arenamod.admin_setexp", amount).method_27692(class_124.field_1060), false);
        }
        return 1;
    }

    /** /arena admin settrophy <targets> <amount> - 设置玩家奖杯数量 */
    private static int adminSetTrophy(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        Collection<class_3222> targets = class_2186.method_9312(ctx, "targets");
        int amount = IntegerArgumentType.getInteger(ctx, "amount");

        for (class_3222 target : targets) {
            GameSaveManager.getInstance().saveTrophyCount(target.method_5682(), target.method_5667(), amount);
            target.method_7353(class_2561.method_43469("message.arenamod.admin_settrophy", amount).method_27692(class_124.field_1060), false);
        }
        return 1;
    }
}
