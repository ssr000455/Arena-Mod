package com.qidai.arenamod.game;

import com.qidai.arenamod.ArenaMod;
import com.qidai.arenamod.config.ArenaConfig;
import com.qidai.arenamod.dimension.ModDimensions;
import com.qidai.arenamod.item.ModItems;
import com.qidai.arenamod.network.ModNetworking;
import com.qidai.arenamod.wave.WaveDefinition;
import com.qidai.arenamod.wave.WaveSpawner;
import net.fabricmc.fabric.api.dimension.v1.FabricDimensions;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1308;
import net.minecraft.class_1646;
import net.minecraft.class_1799;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2595;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5321;
import net.minecraft.class_5454;
import net.minecraft.server.MinecraftServer;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class GameManager {
    private static GameManager INSTANCE;

    private final Map<UUID, GameInstance> activeGames = new ConcurrentHashMap<>();

    // 基于 tick 的任务调度器（替代 Thread.sleep）
    private final List<ScheduledTask> scheduledTasks = new CopyOnWriteArrayList<>();

    // 玩家进入竞技场前的原始位置缓存（退出时传送回此处）
    private final Map<UUID, SavedPosition> savedPositions = new ConcurrentHashMap<>();

    private GameManager() {}

    public static GameManager getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new GameManager();
        }
        return INSTANCE;
    }

    // ===== Tick 调度器 =====

    /** 每个服务端 tick 调用一次，驱动所有延迟任务 */
    public void tickScheduler() {
        synchronized (scheduledTasks) {
            scheduledTasks.removeIf(task -> {
                task.ticksRemaining--;
                if (task.ticksRemaining <= 0) {
                    try {
                        task.action.run();
                    } catch (Exception e) {
                        ArenaMod.LOGGER.error("调度任务执行异常", e);
                    }
                    return true;
                }
                return false;
            });
        }
    }

    /** 为指定玩家调度一个延迟任务（延迟单位为 tick） */
    private void scheduleTask(UUID playerUuid, int delayTicks, Runnable action) {
        // 原子操作：先取消旧任务再添加新任务
        synchronized (scheduledTasks) {
            scheduledTasks.removeIf(task -> task.playerUuid.equals(playerUuid));
            scheduledTasks.add(new ScheduledTask(playerUuid, delayTicks, action));
        }
    }

    /** 取消指定玩家的所有待执行任务 */
    private void cancelPlayerTasks(UUID playerUuid) {
        synchronized (scheduledTasks) {
            scheduledTasks.removeIf(task -> task.playerUuid.equals(playerUuid));
        }
    }

    private static class ScheduledTask {
        final UUID playerUuid;
        int ticksRemaining;
        final Runnable action;

        ScheduledTask(UUID playerUuid, int ticks, Runnable action) {
            this.playerUuid = playerUuid;
            this.ticksRemaining = ticks;
            this.action = action;
        }
    }

    // ===== 进度同步 =====

    /** 向客户端发送游戏进度信息（用于 HUD 显示） */
    private void syncProgressToClient(class_3222 player, GameInstance game) {
        if (player == null || game == null) return;
        MinecraftServer server = player.method_5682();
        if (server == null) return;
        var buf = PacketByteBufs.create();
        buf.writeInt(game.getGameMode().ordinal()); // 0=单人, 1=PVP
        buf.writeInt(game.getCurrentWaveIndex());
        buf.writeInt(game.getCurrentBatchIndex());
        buf.writeBoolean(game.getCurrentWave() != null);
        if (game.getCurrentWave() != null) {
            buf.writeInt(game.getCurrentWave().batches().size());
        }
        buf.writeInt(game.getState().ordinal());
        buf.writeInt(game.getTotalExpPoints());
        buf.writeInt(game.getLives());
        // PVP 额外数据（含总时限）
        if (game.isPVP()) {
            buf.writeInt(game.getPvpRemainingMs() / 50);  // ms → ticks for client
            buf.writeInt(game.getPvpAliveCount(server));
            buf.writeInt(game.getPvpTotalPlayerCount());
            buf.writeInt(GameInstance.getPvpTimeLimitMillis() / 50);
        }
        ServerPlayNetworking.send(player, ModNetworking.GAME_PROGRESS_ID, buf);
    }

    // ===== 背包/效果管理 =====

    /** 保存玩家背包和效果到 GameInstance，然后清空 */
    private void saveAndClearPlayerItems(class_3222 player, GameInstance game) {
        class_2487 inventoryNbt = new class_2487();
        class_2499 items = player.method_31548().method_7384(new class_2499());
        inventoryNbt.method_10566("items", items);

        class_2487 effectsNbt = new class_2487();
        class_2499 effects = new class_2499();
        player.method_6026().forEach(effect -> {
            class_2487 e = new class_2487();
            effect.method_5582(e);
            effects.add(e);
        });
        effectsNbt.method_10566("effects", effects);

        if (game.isPVP()) {
            // PVP模式：每人独立存档
            game.setSavedInventory(player.method_5667(), inventoryNbt);
            game.setSavedEffects(player.method_5667(), effectsNbt);
        } else {
            // 单人模式：共享存档（每个玩家各自有独立GameInstance）
            game.setSavedInventory(inventoryNbt);
            game.setSavedEffects(effectsNbt);
        }

        player.method_31548().method_5448();
        player.method_6012();
    }

    /** 在主世界生成箱子，归还玩家物品，恢复效果 */
    private void spawnReturnChestAndRestore(class_3222 player, GameInstance game) {
        MinecraftServer server = player.method_5682();
        if (server == null) return;

        class_2487 invNbt;
        class_2487 effNbt;

        if (game.isPVP()) {
            invNbt = game.getSavedInventory(player.method_5667());
            effNbt = game.getSavedEffects(player.method_5667());
        } else {
            invNbt = game.getSavedInventory();
            effNbt = game.getSavedEffects();
        }

        if (invNbt == null) return;

        class_3218 overworld = server.method_3847(net.minecraft.class_1937.field_25179);
        if (overworld == null) return;

        class_2338 chestPos = player.method_24515().method_10086(2);

        overworld.method_8501(chestPos, class_2246.field_10034.method_9564());
        class_2595 chest = (class_2595) overworld.method_8321(chestPos);

        if (chest != null) {
            class_2499 items = invNbt.method_10554("items", 10);
            for (int i = 0; i < items.size(); i++) {
                class_2487 itemNbt = items.method_10602(i);
                int slot = itemNbt.method_10571("Slot") & 255;
                if (slot < chest.method_5439()) {
                    class_1799 stack = class_1799.method_7915(itemNbt);
                    if (!stack.method_7960()) {
                        chest.method_5447(slot, stack);
                    }
                }
            }
        }

        if (effNbt != null) {
            class_2499 effects = effNbt.method_10554("effects", 10);
            for (int i = 0; i < effects.size(); i++) {
                class_2487 e = effects.method_10602(i);
                class_1293 effect = class_1293.method_5583(e);
                if (effect != null) {
                    player.method_6092(effect);
                }
            }
        }
    }

    // ===== 存档继续 =====

    public void resumeGame(class_3222 player, GameSaveManager.GameSaveData saveData) {
        if (isPlayerInGame(player)) return;

        MinecraftServer server = player.method_5682();
        if (server == null) return;

        class_3218 arenaWorld = server.method_3847(ModDimensions.ARENA_WORLD_KEY);
        if (arenaWorld == null) return;

        ArenaBuilder.buildArena(arenaWorld, saveData.arenaCenter());

        // 根据配置文件设置竞技场维度规则
        arenaWorld.method_8450().method_20746(class_1928.field_19391).method_20758(ArenaConfig.getInstance().isMonsterDrops(), server);
        arenaWorld.method_8450().method_20746(class_1928.field_19389).method_20758(ArenaConfig.getInstance().isKeepInventoryOnDeath(), server);

        GameInstance game = new GameInstance(player, saveData.gameMode(), saveData.arenaCenter());

        for (int w = 0; w < saveData.waveIndex(); w++) game.advanceToNextBatch();
        for (int b = 0; b < saveData.batchIndex(); b++) game.advanceToNextBatch();

        game.setState(GameState.IN_PROGRESS);
        game.setTotalExpPoints(saveData.expPoints());
        game.setTrophyCount(saveData.trophyCount());
        game.setPassCount(saveData.passCount());
        game.setBlockMerchantTier(Math.max(1, saveData.blockMerchantTier()));
        game.setPotionMerchantTier(Math.max(1, saveData.potionMerchantTier()));
        game.setLives(Math.max(1, saveData.lives()));
        game.setCycleCount(Math.max(0, saveData.cycleCount()));
        activeGames.put(player.method_5667(), game);

        class_2338 spawnPos = saveData.arenaCenter();
        class_5454 target = new class_5454(
                new class_243(spawnPos.method_10263() + 0.5, spawnPos.method_10264() + 1, spawnPos.method_10260() + 0.5),
                class_243.field_1353, 0, 0
        );
        savePlayerPosition(player);
        FabricDimensions.teleport(player, arenaWorld, target);

        restoreExpItems(player, saveData.expPoints());
        player.method_7353(class_2561.method_43471("message.arenamod.save_loaded").method_27692(class_124.field_1060), false);

        applyArenaEffects(player);
        scheduleWaveStart(player, game, ArenaConfig.getInstance().getWaveResumeDelay());
    }

    // ===== 开始游戏 =====

    public void startSinglePlayerGame(class_3222 player) {
        if (isPlayerInGame(player)) {
            player.method_7353(class_2561.method_43471("message.arenamod.already_in_game").method_27692(class_124.field_1061), false);
            return;
        }

        MinecraftServer server = player.method_5682();
        if (server == null) return;

        class_3218 arenaWorld = server.method_3847(ModDimensions.ARENA_WORLD_KEY);
        if (arenaWorld == null) {
            player.method_7353(class_2561.method_43471("message.arenamod.arena_dimension_unloaded").method_27692(class_124.field_1061), false);
            return;
        }

        int offsetX = (int) (Math.random() * 10000) - 5000;
        class_2338 arenaCenter = new class_2338(offsetX, ArenaBuilder.getFloorY() + 1, 0);

        ArenaBuilder.buildArena(arenaWorld, arenaCenter);

        // 根据配置文件设置竞技场维度规则
        arenaWorld.method_8450().method_20746(class_1928.field_19391).method_20758(ArenaConfig.getInstance().isMonsterDrops(), server);
        arenaWorld.method_8450().method_20746(class_1928.field_19389).method_20758(ArenaConfig.getInstance().isKeepInventoryOnDeath(), server);

        GameInstance game = new GameInstance(player, GameMode.SINGLE_PLAYER, arenaCenter);
        game.setState(GameState.IN_PROGRESS);
        activeGames.put(player.method_5667(), game);

        saveAndClearPlayerItems(player, game);

        class_2338 spawnPos = arenaCenter;
        class_5454 target = new class_5454(
                new class_243(spawnPos.method_10263() + 0.5, spawnPos.method_10264() + 1, spawnPos.method_10260() + 0.5),
                class_243.field_1353, 0, 0
        );
        savePlayerPosition(player);
        FabricDimensions.teleport(player, arenaWorld, target);

        applyArenaEffects(player);

        player.method_7353(class_2561.method_43471("message.arenamod.single_player_start").method_27692(class_124.field_1060), false);
        player.method_7353(class_2561.method_43469("message.arenamod.lives_remaining", game.getLives()).method_27692(class_124.field_1054), false);
        player.method_7353(class_2561.method_43471("message.arenamod.first_wave_coming").method_27692(class_124.field_1054), false);

        scheduleWaveStart(player, game, ArenaConfig.getInstance().getWaveStartDelay());
    }

    /** 给玩家施加夜视效果（竞技场围蔽导致黑暗） */
    private void applyArenaEffects(class_3222 player) {
        player.method_6092(new class_1293(class_1294.field_5925, 999999, 0, false, false));
    }

    public void joinPVPQueue(class_3222 player) {
        MatchmakingManager.getInstance().addToQueue(player);
    }

    public void startPVPGame(List<class_3222> players) {
        MinecraftServer server = players.get(0).method_5682();
        if (server == null) return;

        class_3218 arenaWorld = server.method_3847(ModDimensions.ARENA_WORLD_KEY);
        if (arenaWorld == null) return;

        int offsetX = (int) (Math.random() * 10000) - 5000;
        class_2338 arenaCenter = new class_2338(offsetX, ArenaBuilder.getFloorY() + 1, 0);
        ArenaBuilder.buildPvpArena(arenaWorld, arenaCenter);

        GameInstance game = new GameInstance(players.get(0), GameMode.PVP, arenaCenter);
        game.setState(GameState.IN_PROGRESS);

        long worldTime = arenaWorld.method_8510();
        game.setLastFloorToggleTime(worldTime);
        game.setLastBlockClearTime(worldTime);
        game.setPvpStartTimeMs(System.currentTimeMillis());
        game.setPvpTotalPlayerCount(players.size());    // 记录总人数

        for (class_3222 player : players) {
            game.getPvpPlayers().add(player.method_5667());
            activeGames.put(player.method_5667(), game);

            saveAndClearPlayerItems(player, game);

            class_2338 spawnPos = arenaCenter;
            class_5454 target = new class_5454(
                    new class_243(spawnPos.method_10263() + 0.5, spawnPos.method_10264() + 1, spawnPos.method_10260() + 0.5),
                    class_243.field_1353, 0, 0
            );
            savePlayerPosition(player);
            FabricDimensions.teleport(player, arenaWorld, target);

            applyArenaEffects(player);

            player.method_7353(class_2561.method_43469("message.arenamod.pvp_start", 1200).method_27692(class_124.field_1061), false);
        }
    }

    // ===== 波次调度 =====

    private void scheduleWaveStart(class_3222 player, GameInstance game, int delayTicks) {
        scheduleTask(player.method_5667(), delayTicks, () -> {
            spawnNextBatch(player, game);
        });
    }

    public void spawnNextBatch(class_3222 player, GameInstance game) {
        if (!activeGames.containsKey(player.method_5667())) return;
        if (game.getState() == GameState.VICTORY || game.getState() == GameState.DEFEAT) return;

        MinecraftServer server = player.method_5682();
        if (server == null) return;

        class_3218 arenaWorld = server.method_3847(ModDimensions.ARENA_WORLD_KEY);
        if (arenaWorld == null) return;

        WaveDefinition.Batch batch = game.getCurrentBatch();
        if (batch == null) {
            game.setState(GameState.VICTORY);
            player.method_7353(class_2561.method_43471("message.arenamod.all_waves_cleared").method_27692(class_124.field_1065), false);
            endGame(player, game);
            return;
        }

        game.setState(GameState.BATCH_COOLDOWN);

        int waveNum = game.getCurrentWaveIndex() + 1;
        int batchNum = game.getCurrentBatchIndex() + 1;
        int totalBatches = game.getCurrentWave().batches().size();

        player.method_7353(class_2561.method_43469("message.arenamod.wave_batch_info", waveNum, batchNum, totalBatches)
                .method_27692(class_124.field_1075), false);

        List<class_1308> spawned = WaveSpawner.spawnBatch(arenaWorld, game, batch);
        game.getCurrentBatchMobs().clear();
        game.getCurrentBatchMobs().addAll(spawned);

        player.method_7353(class_2561.method_43469("message.arenamod.monsters_spawned", spawned.size()).method_27692(class_124.field_1080), false);

        game.setState(GameState.IN_PROGRESS);
        syncProgressToClient(player, game);
        scheduleBatchCheck(player, game);
    }

    private void scheduleBatchCheck(class_3222 player, GameInstance game) {
        int interval = ArenaConfig.getInstance().getBatchCheckInterval();
        scheduleTask(player.method_5667(), interval, () -> {
            checkBatchCompletion(player, game);
        });
    }

    private void checkBatchCompletion(class_3222 player, GameInstance game) {
        if (!activeGames.containsKey(player.method_5667())) return;
        if (game.getState() == GameState.VICTORY || game.getState() == GameState.DEFEAT) return;

        List<class_1308> mobs = game.getCurrentBatchMobs();
        mobs.removeIf(m -> !m.method_5805());

        if (mobs.isEmpty()) {
            player.method_7353(class_2561.method_43471("message.arenamod.batch_cleared").method_27692(class_124.field_1060), false);
            player.method_17356(class_3417.field_14627, class_3419.field_15248, 1.0f, 1.0f);

            boolean hasNext = game.advanceToNextBatch();
            if (!hasNext && game.getState() == GameState.VICTORY) {
                game.incrementCycle();
                int cycle = game.getCycleCount();
                int bonusExp = ArenaConfig.getInstance().getCycleBonusExp();
                int bonusTrophies = ArenaConfig.getInstance().getCycleBonusTrophies();
                for (int t = 0; t < bonusTrophies; t++) game.addTrophy();
                game.addExpPoints(bonusExp);
                if (bonusExp > 0) {
                    player.method_31548().method_7398(new class_1799(ModItems.EXP_POINT, bonusExp));
                }
                player.method_7353(class_2561.method_43469("message.arenamod.cycle_complete", cycle, bonusExp, bonusTrophies)
                        .method_27692(class_124.field_1065), false);
                GameSaveManager.getInstance().deleteSave(player.method_5682(), player.method_5667());

                game.resetWaveProgress();
                game.setState(GameState.IN_PROGRESS);
                player.method_7353(class_2561.method_43471("message.arenamod.new_cycle_start").method_27692(class_124.field_1060), false);
                syncProgressToClient(player, game);
                scheduleWaveStart(player, game, ArenaConfig.getInstance().getWaveStartDelay());
            } else if (game.getState() == GameState.WAVE_COMPLETE) {
                int nextWave = game.getCurrentWaveIndex() + 1;
                MinecraftServer server = player.method_5682();
                if (server != null) {
                    class_3218 arenaWorld = server.method_3847(ModDimensions.ARENA_WORLD_KEY);
                    if (arenaWorld != null) {
                        ArenaBuilder.removeAllMerchants(arenaWorld, game);
                        game.clearAllMerchantUuids();
                    }
                }
                player.method_7353(class_2561.method_43469("message.arenamod.wave_complete", game.getCurrentWaveIndex(), nextWave)
                        .method_27692(class_124.field_1076), false);
                player.method_7353(class_2561.method_43471("message.arenamod.resummon_merchant_hint")
                        .method_27692(class_124.field_1054), false);
                syncProgressToClient(player, game);
                scheduleWaveStart(player, game, ArenaConfig.getInstance().getWaveStartDelay());
            } else {
                syncProgressToClient(player, game);
                scheduleWaveStart(player, game, ArenaConfig.getInstance().getWaveBatchDelay());
            }
        } else {
            scheduleBatchCheck(player, game);
        }
    }

    // ===== EXP 物品管理 =====

    public void clearExpItems(class_3222 player) {
        for (int i = 0; i < player.method_31548().method_5439(); i++) {
            class_1799 stack = player.method_31548().method_5438(i);
            if (stack.method_31574(ModItems.EXP_POINT)) {
                player.method_31548().method_5447(i, class_1799.field_8037);
            }
        }
    }

    public void restoreExpItems(class_3222 player, int expPoints) {
        if (expPoints <= 0) return;
        final int MAX_STACK = 9999;
        while (expPoints > 0) {
            int amount = Math.min(expPoints, MAX_STACK);
            player.method_31548().method_7398(new class_1799(ModItems.EXP_POINT, amount));
            expPoints -= amount;
        }
    }

    // ===== 商人交互 =====

    public void openMerchant(class_3222 player, GameInstance game, int merchantType) {
        var buf = PacketByteBufs.create();
        int tier = game.getMerchantTier(merchantType);
        buf.writeInt(tier);
        buf.writeBoolean(tier < 3);
        buf.writeInt(merchantType);
        ServerPlayNetworking.send(player, ModNetworking.OPEN_MERCHANT_ID, buf);
    }

    public void handleMerchantBuy(class_3222 player, int itemIndex, int merchantType) {
        GameInstance game = activeGames.get(player.method_5667());
        if (game == null || game.getGameMode() != GameMode.SINGLE_PLAYER) return;

        if (itemIndex == -1) {
            handleMerchantUpgrade(player, game, merchantType);
            return;
        }

        int tier = game.getMerchantTier(merchantType);
        var items = MerchantData.getItemsForMerchant(merchantType, tier);
        if (itemIndex < 0 || itemIndex >= items.size()) return;

        MerchantData.MerchantItem merchantItem = items.get(itemIndex);

        int expCount = countExpItems(player);
        if (expCount < merchantItem.expCost()) {
            player.method_7353(class_2561.method_43469("message.arenamod.exp_not_enough", merchantItem.expCost())
                    .method_27692(class_124.field_1061), false);
            return;
        }

        removeExpItems(player, merchantItem.expCost());
        game.addExpPoints(-merchantItem.expCost());

        class_1799 bought = merchantItem.item().method_7972();
        player.method_31548().method_7398(bought);

        if (merchantType == MerchantData.MERCHANT_TYPE_ITEM && MerchantData.isPassItem(bought)) {
            game.addPassCount(bought.method_7947());
        }

        player.method_7353(class_2561.method_43469("message.arenamod.purchase_success", merchantItem.expCost())
                .method_27692(class_124.field_1060), false);
    }

    private void handleMerchantUpgrade(class_3222 player, GameInstance game, int merchantType) {
        int currentTier = game.getMerchantTier(merchantType);
        if (currentTier >= 3) {
            player.method_7353(class_2561.method_43471("message.arenamod.max_tier_reached").method_27692(class_124.field_1061), false);
            return;
        }

        int cost = MerchantData.getUpgradeCost(currentTier);
        int expCount = countExpItems(player);
        if (expCount < cost) {
            player.method_7353(class_2561.method_43469("message.arenamod.exp_not_enough_upgrade", cost)
                    .method_27692(class_124.field_1061), false);
            return;
        }

        removeExpItems(player, cost);
        game.addExpPoints(-cost);

        int newTier = currentTier + 1;
        String merchantName = MerchantData.getMerchantName(merchantType);
        String tierName = switch (newTier) {
            case 2 -> net.minecraft.class_2561.method_43471("merchant.arenamod.tier.2").getString();
            case 3 -> net.minecraft.class_2561.method_43471("merchant.arenamod.tier.3").getString();
            default -> net.minecraft.class_2561.method_43471("merchant.arenamod.tier.unknown").getString();
        };

        game.setMerchantTier(merchantType, newTier);
        game.setMerchantUpgradePurchased(merchantType, false);
        player.method_7353(class_2561.method_43469("message.arenamod.merchant_upgraded", merchantName, tierName).method_27692(class_124.field_1060), false);
    }

    private int countExpItems(class_3222 player) {
        int count = 0;
        for (int i = 0; i < player.method_31548().method_5439(); i++) {
            class_1799 stack = player.method_31548().method_5438(i);
            if (stack.method_31574(ModItems.EXP_POINT)) {
                count += stack.method_7947();
            }
        }
        return count;
    }

    private void removeExpItems(class_3222 player, int amount) {
        for (int i = 0; i < player.method_31548().method_5439() && amount > 0; i++) {
            class_1799 stack = player.method_31548().method_5438(i);
            if (stack.method_31574(ModItems.EXP_POINT)) {
                int toRemove = Math.min(amount, stack.method_7947());
                stack.method_7934(toRemove);
                amount -= toRemove;
            }
        }
    }

    // ===== 商人召唤 =====

    public void spawnPlayerMerchants(class_3222 player) {
        GameInstance game = activeGames.get(player.method_5667());
        if (game == null || game.getGameMode() != GameMode.SINGLE_PLAYER) {
            player.method_7353(class_2561.method_43471("message.arenamod.not_in_single_player").method_27692(class_124.field_1061), false);
            return;
        }

        MinecraftServer server = player.method_5682();
        if (server == null) return;

        class_3218 arenaWorld = server.method_3847(ModDimensions.ARENA_WORLD_KEY);
        if (arenaWorld == null) return;

        class_2338 playerPos = player.method_24515();

        ArenaBuilder.removeAllMerchants(arenaWorld, game);
        game.clearAllMerchantUuids();

        class_2338[] offsets = {
                new class_2338(-2, 0, 0),
                new class_2338(2, 0, 0),
                new class_2338(0, 0, 2)
        };

        var itemMerchant = ArenaBuilder.spawnMerchant(arenaWorld, playerPos.method_10081(offsets[0]));
        if (itemMerchant != null) {
            game.setMerchantUuid(MerchantData.MERCHANT_TYPE_ITEM, itemMerchant.method_5667());
        }

        var blockMerchant = ArenaBuilder.spawnBlockMerchant(arenaWorld, playerPos.method_10081(offsets[1]));
        if (blockMerchant != null) {
            game.setMerchantUuid(MerchantData.MERCHANT_TYPE_BLOCK, blockMerchant.method_5667());
        }

        var potionMerchant = ArenaBuilder.spawnPotionMerchant(arenaWorld, playerPos.method_10081(offsets[2]));
        if (potionMerchant != null) {
            game.setMerchantUuid(MerchantData.MERCHANT_TYPE_POTION, potionMerchant.method_5667());
        }

        player.method_7353(class_2561.method_43471("message.arenamod.merchant_summoned").method_27692(class_124.field_1060), false);
    }

    // ===== PVP Tick =====

    public void tickArenaWorld(class_3218 world) {
        long gameTime = world.method_8510();
        Set<GameInstance> processedGames = new HashSet<>();
        MinecraftServer server = world.method_8503();

        for (GameInstance game : activeGames.values()) {
            if (!processedGames.add(game)) continue;
            if (game.getGameMode() != GameMode.PVP) continue;
            if (game.getState() == GameState.VICTORY || game.getState() == GameState.DEFEAT) continue;

            tickPvpGame(world, game, gameTime);

            // PVP 时限检查
            if (game.getPvpRemainingMs() <= 0) {
                endPvpByTimeLimit(server, game);
                continue;
            }
        }

        // 每秒同步一次进度（PVP实时更新倒计时和人数）
        if (gameTime % 20 == 0 && server != null) {
            Set<GameInstance> syncedGames = new HashSet<>();
            for (Map.Entry<UUID, GameInstance> entry : activeGames.entrySet()) {
                GameInstance game = entry.getValue();
                if (game.getState() == GameState.VICTORY || game.getState() == GameState.DEFEAT) continue;
                if (game.getGameMode() == GameMode.PVP && syncedGames.add(game)) {
                    for (UUID uid : game.getAllPvpParticipants()) {
                        class_3222 p = server.method_3760().method_14602(uid);
                        if (p != null) syncProgressToClient(p, game);
                    }
                }
            }

            // 边界检查
            for (Map.Entry<UUID, GameInstance> entry : activeGames.entrySet()) {
                GameInstance game = entry.getValue();
                if (game.getState() == GameState.VICTORY || game.getState() == GameState.DEFEAT) continue;
                class_3222 player = server.method_3760().method_14602(entry.getKey());
                if (player != null && player.method_37908().method_27983().equals(ModDimensions.ARENA_WORLD_KEY)) {
                    checkPlayerBoundary(player, game);
                }
            }
        }
    }

    private void tickPvpGame(class_3218 world, GameInstance game, long gameTime) {
        var config = ArenaConfig.getInstance();
        if (!game.isFloorRemoved()) {
            if (gameTime - game.getLastFloorToggleTime() >= config.getPvpFloorToggleInterval()) {
                ArenaBuilder.removeFloor(world, game.getArenaCenter(), game.getArenaHalf());
                game.setFloorRemoved(true);
                game.setFloorRestoreScheduledTime(gameTime);
                game.setLastFloorToggleTime(gameTime);
            }
        } else {
            if (gameTime - game.getFloorRestoreScheduledTime() >= config.getPvpFloorRestoreDelay()) {
                ArenaBuilder.restoreFloor(world, game.getArenaCenter(), game.getArenaHalf());
                game.setFloorRemoved(false);
                game.setLastFloorToggleTime(gameTime);
            }
        }

        if (gameTime - game.getLastBlockClearTime() >= config.getPvpBlockClearInterval()) {
            ArenaBuilder.clearNonStructuralBlocks(world, game.getArenaCenter(), game.getArenaHalf(), game.getArenaHeight());
            game.getPlacedBlocks().clear();
            game.setLastBlockClearTime(gameTime);
        }
    }

    private void checkPlayerBoundary(class_3222 player, GameInstance game) {
        class_2338 playerPos = player.method_24515();
        class_2338 center = game.getArenaCenter();
        int half = game.getArenaHalf();

        if (!ArenaBuilder.isInBounds(playerPos, center, half)) {
            if (game.getGameMode() == GameMode.PVP) {
                // 已在观战模式中则跳过
                if (game.isSpectator(player.method_5667())) return;

                player.method_7353(class_2561.method_43471("message.arenamod.escaped_arena_fail").method_27692(class_124.field_1061), false);

                // 掉落所有物品（死亡掉落）
                for (int i = 0; i < player.method_31548().method_5439(); i++) {
                    class_1799 stack = player.method_31548().method_5438(i);
                    if (!stack.method_7960()) {
                        player.method_7329(stack, true, false);
                    }
                }
                player.method_31548().method_5448();

                game.getPvpPlayers().remove(player.method_5667());
                game.addSpectator(player.method_5667());
                cancelPlayerTasks(player.method_5667());

                // 设置观战模式并传送回竞技场中心
                player.method_7336(net.minecraft.class_1934.field_9219);
                MinecraftServer server = player.method_5682();
                if (server != null) {
                    class_3218 arenaWorld = server.method_3847(ModDimensions.ARENA_WORLD_KEY);
                    if (arenaWorld != null) {
                        class_2338 c = game.getArenaCenter();
                        class_5454 target = new class_5454(
                                new class_243(c.method_10263() + 0.5, c.method_10264() + 1, c.method_10260() + 0.5),
                                class_243.field_1353, 0, 0
                        );
                        FabricDimensions.teleport(player, arenaWorld, target);
                    }
                    awardAllPvpPlayersExcept(server, game, player.method_5667(), ArenaConfig.getInstance().getPvpExpOnElimination());
                    checkPvpWinner(server, game);
                }
            } else {
                player.method_7353(class_2561.method_43471("message.arenamod.escaped_arena_game_over").method_27692(class_124.field_1061), false);
                GameSaveManager.getInstance().deleteSave(player.method_5682(), player.method_5667());
                endGame(player, game);
            }
        }
    }

    private void awardAllPvpPlayersExcept(MinecraftServer server, GameInstance game, UUID excludeUuid, int expAmount) {
        for (UUID uid : game.getPvpPlayers()) {
            if (uid.equals(excludeUuid)) continue;
            class_3222 p = server.method_3760().method_14602(uid);
            if (p != null) {
                if (expAmount > 0) {
                    p.method_31548().method_7398(new class_1799(ModItems.EXP_POINT, expAmount));
                }
                game.addExpPoints(expAmount);
                p.method_7353(class_2561.method_43469("message.arenamod.player_eliminated_award", expAmount).method_27692(class_124.field_1060), false);
            }
        }
    }

    /** PVP时间到处理 */
    private void endPvpByTimeLimit(MinecraftServer server, GameInstance game) {
        if (server == null) return;

        // 统计存活玩家人数
        List<class_3222> alivePlayers = new ArrayList<>();
        for (UUID uid : game.getPvpPlayers()) {
            class_3222 p = server.method_3760().method_14602(uid);
            if (p != null && p.method_5805()) {
                alivePlayers.add(p);
            }
        }

        boolean singleWinner = (alivePlayers.size() == 1);

        // 处理所有参与者（存活玩家 + 观众）
        List<UUID> allParticipants = game.getAllPvpParticipants();
        for (UUID uid : allParticipants) {
            class_3222 p = server.method_3760().method_14602(uid);
            if (p != null) {
                if (alivePlayers.contains(p)) {
                    var config = ArenaConfig.getInstance();
                    if (singleWinner) {
                        // Only one remains → victory
                        int expAmount = config.getPvpWinnerExp();
                        int trophies = config.getPvpWinnerTrophy();
                        for (int t = 0; t < trophies; t++) game.addTrophy();
                        if (expAmount > 0) {
                            p.method_31548().method_7398(new class_1799(ModItems.EXP_POINT, expAmount));
                        }
                        game.addExpPoints(expAmount);
                        p.method_7353(class_2561.method_43469("message.arenamod.pvp_time_up_winner", expAmount)
                                .method_27692(class_124.field_1065), false);
                    } else {
                        // Multiple survivors → draw
                        int expAmount = config.getPvpDrawExp();
                        if (expAmount > 0) {
                            p.method_31548().method_7398(new class_1799(ModItems.EXP_POINT, expAmount));
                        }
                        game.addExpPoints(expAmount);
                        p.method_7353(class_2561.method_43469("message.arenamod.pvp_time_up_draw", expAmount)
                                .method_27692(class_124.field_1054), false);
                    }
                } else {
                    p.method_7353(class_2561.method_43471("message.arenamod.pvp_time_up_eliminated").method_27692(class_124.field_1061), false);
                }
                clearExpItems(p);
                p.method_7336(net.minecraft.class_1934.field_9215);
                spawnReturnChestAndRestore(p, game);
                teleportToOverworld(p, game);
                activeGames.remove(uid);
                game.getPvpPlayers().remove(uid);
                game.getPvpSpectators().remove(uid);
                cancelPlayerTasks(uid);
            } else {
                activeGames.remove(uid);
                game.getPvpPlayers().remove(uid);
                game.getPvpSpectators().remove(uid);
            }
        }
        game.setState(GameState.DEFEAT);
    }

    private void checkPvpWinner(MinecraftServer server, GameInstance game) {
        if (game.getPvpPlayers().size() <= 1) {
            var config = ArenaConfig.getInstance();
            int expAmount = config.getPvpWinnerExp();
            int trophies = config.getPvpWinnerTrophy();
            for (UUID uid : game.getPvpPlayers()) {
                class_3222 winner = server.method_3760().method_14602(uid);
                if (winner != null) {
                    for (int t = 0; t < trophies; t++) game.addTrophy();
                    if (expAmount > 0) {
                        winner.method_31548().method_7398(new class_1799(ModItems.EXP_POINT, expAmount));
                    }
                    game.addExpPoints(expAmount);
                    winner.method_7353(class_2561.method_43469("message.arenamod.pvp_victory", expAmount, game.getTrophyCount())
                            .method_27692(class_124.field_1065), false);
                }
            }
            endPvpGame(server, game);
        }
    }

    /** PVP游戏结束：为所有参与者归还物品并传送回主世界 */
    private void endPvpGame(MinecraftServer server, GameInstance game) {
        for (UUID uid : game.getAllPvpParticipants()) {
            class_3222 p = server.method_3760().method_14602(uid);
            if (p != null) {
                clearExpItems(p);
                p.method_7336(net.minecraft.class_1934.field_9215);
                spawnReturnChestAndRestore(p, game);
                teleportToOverworld(p, game);
                activeGames.remove(uid);
                cancelPlayerTasks(uid);
            } else {
                activeGames.remove(uid);
            }
            game.getPvpPlayers().remove(uid);
            game.getPvpSpectators().remove(uid);
        }
        GameSaveManager.getInstance().addTrophyCount(server, game.getPlayerUuid(), game.getTrophyCount());
        game.setState(GameState.DEFEAT);
        // PVP游戏结束：清理竞技场和玩家放置的方块
        if (server != null) {
            class_3218 arenaWorld = server.method_3847(ModDimensions.ARENA_WORLD_KEY);
            if (arenaWorld != null) {
                ArenaBuilder.clearPvpArena(arenaWorld, game.getArenaCenter(), game.getArenaHalf(), game.getArenaHeight());
            }
        }
    }

    /** 保存玩家进入竞技场前的原始位置 */
    private void savePlayerPosition(class_3222 player) {
        savedPositions.put(player.method_5667(), new SavedPosition(
                player.method_19538(),
                player.method_36454(),
                player.method_36455(),
                player.method_37908().method_27983()
        ));
    }

    /** 取出并移除缓存的位置 */
    private SavedPosition takePlayerPosition(UUID playerUuid) {
        return savedPositions.remove(playerUuid);
    }

    private void teleportToOverworld(class_3222 player, GameInstance game) {
        MinecraftServer server = player.method_5682();
        if (server != null) {
            SavedPosition saved = takePlayerPosition(player.method_5667());
            class_243 targetPos = new class_243(0, 64, 0);
            float yaw = 0;
            float pitch = 0;
            class_3218 targetWorld = server.method_3847(net.minecraft.class_1937.field_25179);

            if (saved != null) {
                targetPos = saved.pos;
                yaw = saved.yaw;
                pitch = saved.pitch;
                if (saved.dimension != null) {
                    class_3218 savedWorld = server.method_3847(saved.dimension);
                    if (savedWorld != null) {
                        targetWorld = savedWorld;
                    }
                }
            }
            if (targetWorld != null) {
                class_5454 target = new class_5454(targetPos, class_243.field_1353, yaw, pitch);
                FabricDimensions.teleport(player, targetWorld, target);
            }
        }
    }

    /** 玩家进入竞技场前的位置快照 */
    private record SavedPosition(class_243 pos, float yaw, float pitch, class_5321<class_1937> dimension) {}

    // ===== 结束游戏 =====

    public void endGame(class_3222 player, GameInstance game) {
        activeGames.remove(player.method_5667());
        cancelPlayerTasks(player.method_5667());
        game.setState(GameState.DEFEAT);

        MinecraftServer server = player.method_5682();

        if (server != null && game.getGameMode() == GameMode.PVP) {
            GameSaveManager.getInstance().addTrophyCount(server, player.method_5667(), game.getTrophyCount());
        }

        if (server != null && game.getGameMode() == GameMode.SINGLE_PLAYER) {
            class_3218 arenaWorld = server.method_3847(ModDimensions.ARENA_WORLD_KEY);
            if (arenaWorld != null) {
                ArenaBuilder.removeAllMerchants(arenaWorld, game);
                ArenaBuilder.clearArena(arenaWorld, game.getArenaCenter(), game.getArenaHalf(), game.getArenaHeight());
            }
        }

        // 清理 EXP 追踪（无活跃游戏时全量清理）
        if (activeGames.isEmpty()) {
            WaveSpawner.clearAllTracking();
        }

        clearExpItems(player);

        List<class_1799> protectedItems = new ArrayList<>();
        if (game.getGameMode() == GameMode.SINGLE_PLAYER) {
            List<Integer> passSlots = new ArrayList<>();
            for (int i = 0; i < player.method_31548().method_5439(); i++) {
                class_1799 stack = player.method_31548().method_5438(i);
                if (!stack.method_7960() && MerchantData.isPassItem(stack)) {
                    passSlots.add(i);
                }
            }
            for (int slot : passSlots) {
                player.method_31548().method_5447(slot, class_1799.field_8037);
            }
            int passesAvailable = game.getPassCount();
            for (int i = 0; i < player.method_31548().method_5439() && passesAvailable > 0; i++) {
                class_1799 stack = player.method_31548().method_5438(i);
                if (!stack.method_7960()) {
                    protectedItems.add(stack.method_7972());
                    player.method_31548().method_5447(i, class_1799.field_8037);
                    passesAvailable--;
                }
            }
        }

        if (server != null) {
            teleportToOverworld(player, game);
        }

        spawnReturnChestAndRestore(player, game);

        for (class_1799 stack : protectedItems) {
            player.method_31548().method_7398(stack);
        }
    }

    // ===== 死亡/断线 =====

    public void onPlayerDeath(class_3222 player) {
        GameInstance game = activeGames.get(player.method_5667());
        if (game != null) {
            if (game.getGameMode() == GameMode.SINGLE_PLAYER) {
                game.deductLife();
                if (game.getLives() > 0) {
                    // 根据配置决定是否清除背包（keepInventoryOnDeath = true 时保留物品）
                    if (!ArenaConfig.getInstance().isKeepInventoryOnDeath()) {
                        player.method_31548().method_5448();
                    }
                    clearExpItems(player);
                    class_2338 center = game.getArenaCenter();
                    class_5454 target = new class_5454(
                            new class_243(center.method_10263() + 0.5, center.method_10264() + 1, center.method_10260() + 0.5),
                            class_243.field_1353, 0, 0
                    );
                    MinecraftServer server = player.method_5682();
                    if (server != null) {
                        class_3218 arenaWorld = server.method_3847(ModDimensions.ARENA_WORLD_KEY);
                        if (arenaWorld != null) {
                            FabricDimensions.teleport(player, arenaWorld, target);
                        }
                    }
                    applyArenaEffects(player);
                    player.method_7353(class_2561.method_43469("message.arenamod.items_lost_lives_left", game.getLives())
                            .method_27692(class_124.field_1061), false);
                } else {
                    player.method_7353(class_2561.method_43469("message.arenamod.game_over_at_wave", game.getCurrentWaveIndex() + 1)
                            .method_27692(class_124.field_1061), false);
                    GameSaveManager.getInstance().deleteSave(player.method_5682(), player.method_5667());
                    endGame(player, game);
                }
            } else if (game.getGameMode() == GameMode.PVP) {
                // 防止重复处理（已在观战模式中）
                if (game.isSpectator(player.method_5667())) return;

                // 死亡掉落由Minecraft自动处理，不清除物品
                // 不生成归还箱子（游戏结束时统一归还）
                game.getPvpPlayers().remove(player.method_5667());
                game.addSpectator(player.method_5667());
                cancelPlayerTasks(player.method_5667());

                // 设置观战模式并传送回竞技场中心
                player.method_7336(net.minecraft.class_1934.field_9219);
                MinecraftServer server = player.method_5682();
                if (server != null) {
                    class_3218 arenaWorld = server.method_3847(ModDimensions.ARENA_WORLD_KEY);
                    if (arenaWorld != null) {
                        class_2338 center = game.getArenaCenter();
                        class_5454 target = new class_5454(
                                new class_243(center.method_10263() + 0.5, center.method_10264() + 1, center.method_10260() + 0.5),
                                class_243.field_1353, 0, 0
                        );
                        FabricDimensions.teleport(player, arenaWorld, target);
                    }
                    awardAllPvpPlayersExcept(server, game, player.method_5667(), 20);
                    checkPvpWinner(server, game);
                }
            }
        }
    }

    public void onPlayerDisconnect(class_3222 player) {
        GameInstance game = activeGames.remove(player.method_5667());
        if (game != null) {
            if (game.getGameMode() == GameMode.PVP) {
                game.getPvpPlayers().remove(player.method_5667());
                game.getPvpSpectators().remove(player.method_5667());
                MinecraftServer server = player.method_5682();
                if (server != null) {
                    awardAllPvpPlayersExcept(server, game, player.method_5667(), 20);
                    checkPvpWinner(server, game);
                }
            } else {
                if (player.method_5682() != null) {
                    GameSaveManager.getInstance().saveGame(player.method_5682(), game);
                }
            }
        }

        // 如果玩家断开连接时位于竞技场维度，确保传送回主世界
        // 防止玩家数据被保存到竞技场维度，导致下次进入时出生在竞技场
        if (player.method_37908().method_27983().equals(ModDimensions.ARENA_WORLD_KEY)) {
            MinecraftServer server = player.method_5682();
            if (server != null) {
                SavedPosition saved = savedPositions.remove(player.method_5667());
                class_243 targetPos = new class_243(0, 64, 0);
                float yaw = 0;
                float pitch = 0;
                class_3218 targetWorld = server.method_3847(net.minecraft.class_1937.field_25179);
                if (saved != null) {
                    targetPos = saved.pos;
                    yaw = saved.yaw;
                    pitch = saved.pitch;
                    if (saved.dimension != null) {
                        class_3218 savedWorld = server.method_3847(saved.dimension);
                        if (savedWorld != null) {
                            targetWorld = savedWorld;
                        }
                    }
                }
                if (targetWorld != null) {
                    player.method_14251(targetWorld, targetPos.field_1352, targetPos.field_1351, targetPos.field_1350, yaw, pitch);
                }
            }
        }

        MatchmakingManager.getInstance().removeFromQueue(player);
        cancelPlayerTasks(player.method_5667());
    }

    public boolean isPlayerInGame(class_3222 player) {
        return activeGames.containsKey(player.method_5667());
    }

    public GameInstance getGame(class_3222 player) {
        return activeGames.get(player.method_5667());
    }

    /** 获取所有活跃游戏（供作弊接口等外部调用） */
    public Map<UUID, GameInstance> getAllActiveGames() {
        return Collections.unmodifiableMap(activeGames);
    }
}
