package com.qidai.arenamod.game;

import com.qidai.arenamod.ArenaMod;
import com.qidai.arenamod.config.ArenaConfig;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1646;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

/**
 * 竞技场建造器
 * 生成 80×80（单人）或 30×30（PVP）的竞技场
 * PVP竞技场：双层基岩地基+虚空，无围墙/天花板
 */
public class ArenaBuilder {
    public static int getArenaHalf() { return ArenaConfig.getInstance().getArenaHalf(); }
    public static int getArenaHeight() { return ArenaConfig.getInstance().getArenaHeight(); }
    public static int getPvpArenaHalf() { return ArenaConfig.getInstance().getPvpArenaHalf(); }
    public static int getPvpArenaHeight() { return ArenaConfig.getInstance().getPvpArenaHeight(); }

    private static final int FLOOR_Y = 0;               // 地基Y坐标

    /**
     * 在指定世界以中心位置构建单人模式竞技场
     */
    public static void buildArena(class_3218 world, class_2338 center) {
        buildRectArena(world, center, getArenaHalf(), getArenaHeight());
    }

    /**
     * 在指定世界以中心位置构建PVP竞技场
     * 双层基岩地基，虚空包围，无围墙/天花板
     */
    public static void buildPvpArena(class_3218 world, class_2338 center) {
        int cx = center.method_10263();
        int cz = center.method_10260();
        int half = getPvpArenaHalf();
        int height = getPvpArenaHeight();

        ArenaMod.LOGGER.info("开始建造PVP竞技场，中心: {}, 大小: {}×{}", center, half * 2, half * 2);

        // 1. 清除区域内所有旧方块
        for (int x = cx - half; x <= cx + half; x++) {
            for (int z = cz - half; z <= cz + half; z++) {
                for (int y = 0; y <= height; y++) {
                    world.method_8501(new class_2338(x, y, z), class_2246.field_10124.method_9564());
                }
            }
        }

        // 2. 铺设双层基岩地基 (y=0 和 y=1)
        class_2680 bedrock = class_2246.field_9987.method_9564();
        for (int x = cx - half; x <= cx + half; x++) {
            for (int z = cz - half; z <= cz + half; z++) {
                world.method_8501(new class_2338(x, 0, z), bedrock);
                world.method_8501(new class_2338(x, 1, z), bedrock);
            }
        }

        // 3. 在竞技场南方搭建观战台
        buildPvpSpectatorPlatform(world, center, half);

        ArenaMod.LOGGER.info("PVP竞技场建造完成，大小: {}×{}", half * 2, half * 2);
    }

    /**
     * 在竞技场南方搭建观战台
     * 位置：边界以南3格，10×5的阶梯状石英平台，铺设红毯
     */
    public static void buildPvpSpectatorPlatform(class_3218 world, class_2338 center, int half) {
        int cx = center.method_10263();
        int cz = center.method_10260();
        int platformStartZ = cz + half + 3;  // 边界以南3格

        class_2680 quartz = class_2246.field_10153.method_9564();
        class_2680 redCarpet = class_2246.field_10536.method_9564();

        // 5行阶梯（从北到南逐级升高）
        for (int row = 0; row < 5; row++) {
            int z = platformStartZ + row;
            int yBase = 2 + row;  // 从y=2开始，每行+1

            // 每行10格宽 (X方向)
            for (int x = cx - 5; x <= cx + 4; x++) {
                // 石英块主体
                world.method_8501(new class_2338(x, yBase, z), quartz);
                // 红毯铺面
                world.method_8501(new class_2338(x, yBase + 1, z), redCarpet);
            }
        }
    }

    /**
     * 通用竞技场建造
     */
    private static void buildRectArena(class_3218 world, class_2338 center, int half, int height) {
        ArenaMod.LOGGER.info("开始建造竞技场，中心: {}, 大小: {}×{}", center, half * 2, half * 2);

        int cx = center.method_10263();
        int cz = center.method_10260();

        // 1. 平整地基 - 在 FLOOR_Y 处铺设基岩
        class_2680 bedrock = class_2246.field_9987.method_9564();
        for (int x = cx - half; x <= cx + half; x++) {
            for (int z = cz - half; z <= cz + half; z++) {
                world.method_8501(new class_2338(x, FLOOR_Y, z), bedrock);
                // 清除地基以上的所有方块（重置区域）
                for (int y = FLOOR_Y + 1; y <= height; y++) {
                    world.method_8501(new class_2338(x, y, z), class_2246.field_10124.method_9564());
                }
            }
        }

        // 2. 建造边界围墙（四个边），从 FLOOR_Y 到 height
        class_2680 barrier = class_2246.field_10499.method_9564();
        // 北墙 (z = cz - half)
        for (int x = cx - half; x <= cx + half; x++) {
            for (int y = FLOOR_Y; y <= height; y++) {
                world.method_8501(new class_2338(x, y, cz - half), barrier);
            }
        }
        // 南墙 (z = cz + half)
        for (int x = cx - half; x <= cx + half; x++) {
            for (int y = FLOOR_Y; y <= height; y++) {
                world.method_8501(new class_2338(x, y, cz + half), barrier);
            }
        }
        // 西墙 (x = cx - half)
        for (int z = cz - half + 1; z <= cz + half - 1; z++) {
            for (int y = FLOOR_Y; y <= height; y++) {
                world.method_8501(new class_2338(cx - half, y, z), barrier);
            }
        }
        // 东墙 (x = cx + half)
        for (int z = cz - half + 1; z <= cz + half - 1; z++) {
            for (int y = FLOOR_Y; y <= height; y++) {
                world.method_8501(new class_2338(cx + half, y, z), barrier);
            }
        }

        // 3. 天花板（限高处封顶）
        for (int x = cx - half; x <= cx + half; x++) {
            for (int z = cz - half; z <= cz + half; z++) {
                world.method_8501(new class_2338(x, height, z), barrier);
            }
        }

        ArenaMod.LOGGER.info("竞技场建造完成");
    }

    /**
     * 移除PVP竞技场地板（双层基岩全部移除）
     */
    public static void removeFloor(class_3218 world, class_2338 center, int half) {
        class_2680 air = class_2246.field_10124.method_9564();
        int cx = center.method_10263();
        int cz = center.method_10260();
        for (int x = cx - half + 1; x <= cx + half - 1; x++) {
            for (int z = cz - half + 1; z <= cz + half - 1; z++) {
                world.method_8501(new class_2338(x, 0, z), air);
                world.method_8501(new class_2338(x, 1, z), air);
            }
        }
    }

    /**
     * 恢复PVP竞技场地板（双层基岩全部恢复）
     */
    public static void restoreFloor(class_3218 world, class_2338 center, int half) {
        class_2680 bedrock = class_2246.field_9987.method_9564();
        int cx = center.method_10263();
        int cz = center.method_10260();
        for (int x = cx - half + 1; x <= cx + half - 1; x++) {
            for (int z = cz - half + 1; z <= cz + half - 1; z++) {
                world.method_8501(new class_2338(x, 0, z), bedrock);
                world.method_8501(new class_2338(x, 1, z), bedrock);
            }
        }
    }

    /**
     * 清除竞技场内所有非结构性的玩家放置方块
     */
    public static void clearNonStructuralBlocks(class_3218 world, class_2338 center, int half, int height) {
        class_2680 air = class_2246.field_10124.method_9564();
        int cx = center.method_10263();
        int cz = center.method_10260();
        class_2680 barrier = class_2246.field_10499.method_9564();
        class_2680 bedrock = class_2246.field_9987.method_9564();

        for (int x = cx - half + 1; x <= cx + half - 1; x++) {
            for (int z = cz - half + 1; z <= cz + half - 1; z++) {
                for (int y = FLOOR_Y + 1; y < height; y++) {
                    class_2338 pos = new class_2338(x, y, z);
                    class_2680 state = world.method_8320(pos);
                    if (!state.method_26215() && !state.equals(barrier) && !state.equals(bedrock)) {
                        world.method_8501(pos, air);
                    }
                }
            }
        }
    }

    /**
     * 检查坐标是否在竞技场范围内
     */
    public static boolean isInBounds(class_2338 pos, class_2338 center, int half) {
        int dx = Math.abs(pos.method_10263() - center.method_10263());
        int dz = Math.abs(pos.method_10260() - center.method_10260());
        return dx <= half && dz <= half;
    }

    public static int getFloorY() {
        return FLOOR_Y;
    }

    // ===== 商人 NPC =====

    /**
     * 在指定位置生成商人 NPC
     */
    private static class_1646 spawnVillager(class_3218 world, class_2338 pos, class_2561 name) {
        class_1646 villager = class_1299.field_6077.method_5883(world);
        if (villager != null) {
            villager.method_23327(pos.method_10263() + 0.5, pos.method_10264(), pos.method_10260() + 0.5);
            villager.method_5665(name);
            villager.method_5880(true);
            villager.method_5684(true);
            villager.method_5977(true);
            villager.method_5803(true);
            villager.method_5971();
            villager.method_5875(true);
            world.method_8649(villager);
            ArenaMod.LOGGER.info("{}已生成在 {}", name, pos);
        }
        return villager;
    }

    /**
     * 在指定位置生成物品商人 NPC
     */
    public static class_1646 spawnMerchant(class_3218 world, class_2338 pos) {
        return spawnVillager(world, pos, class_2561.method_43471("merchant.arenamod.merchant_name.item"));
    }

    /**
     * 在指定位置生成方块商人 NPC
     */
    public static class_1646 spawnBlockMerchant(class_3218 world, class_2338 pos) {
        return spawnVillager(world, pos, class_2561.method_43471("merchant.arenamod.merchant_name.block"));
    }

    /**
     * 在指定位置生成药水商人 NPC
     */
    public static class_1646 spawnPotionMerchant(class_3218 world, class_2338 pos) {
        return spawnVillager(world, pos, class_2561.method_43471("merchant.arenamod.merchant_name.potion"));
    }

    /**
     * 通过UUID移除指定商人
     */
    public static void removeMerchantByUuid(class_3218 world, UUID uuid) {
        if (uuid == null) return;
        var entity = world.method_14190(uuid);
        if (entity != null) entity.method_31472();
    }

    /**
     * 移除所有商人（通过GameInstance获取UUID）
     */
    public static void removeAllMerchants(class_3218 world, GameInstance game) {
        removeMerchantByUuid(world, game.getMerchantUuid(MerchantData.MERCHANT_TYPE_ITEM));
        removeMerchantByUuid(world, game.getMerchantUuid(MerchantData.MERCHANT_TYPE_BLOCK));
        removeMerchantByUuid(world, game.getMerchantUuid(MerchantData.MERCHANT_TYPE_POTION));
    }

    /**
     * 清空整个竞技场区域（游戏结束时调用，防止世界文件膨胀）
     */
    public static void clearArena(class_3218 world, class_2338 center, int half, int height) {
        int cx = center.method_10263();
        int cz = center.method_10260();
        class_2680 air = class_2246.field_10124.method_9564();

        for (int x = cx - half; x <= cx + half; x++) {
            for (int z = cz - half; z <= cz + half; z++) {
                for (int y = 0; y <= height; y++) {
                    world.method_8501(new class_2338(x, y, z), air);
                }
            }
        }
        ArenaMod.LOGGER.info("Arena cleared at center={} half={}", center, half);
    }

    /** 清空 PVP 竞技场 */
    public static void clearPvpArena(class_3218 world, class_2338 center, int half, int height) {
        clearArena(world, center, half, height);
    }
}
