package com.qidai.arenamod.game;

import com.qidai.arenamod.ArenaMod;
import com.qidai.arenamod.config.ArenaConfig;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/**
 * PVP matchmaking queue — reads min/max players and timeout from ArenaConfig
 */
public class MatchmakingManager {
    private static MatchmakingManager INSTANCE;

    private final Queue<class_3222> queue = new LinkedList<>();
    private boolean checking = false;

    private MatchmakingManager() {}

    public static MatchmakingManager getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new MatchmakingManager();
        }
        return INSTANCE;
    }

    /**
     * Join the matchmaking queue
     */
    public void addToQueue(class_3222 player) {
        if (queue.contains(player)) {
            player.method_7353(class_2561.method_43471("message.arenamod.already_in_queue").method_27692(class_124.field_1054), false);
            return;
        }

        queue.add(player);
        int minPlayers = ArenaConfig.getInstance().getMatchmakingMinPlayers();
        player.method_7353(class_2561.method_43471("message.arenamod.joined_queue").method_27692(class_124.field_1060), false);
        ArenaMod.LOGGER.info("Player {} joined PvP queue, size: {} (min: {})", player.method_5477().getString(), queue.size(), minPlayers);

        if (queue.size() >= minPlayers && !checking) {
            startMatch();
        }
    }

    /**
     * Remove from queue
     */
    public void removeFromQueue(class_3222 player) {
        queue.remove(player);
    }

    /**
     * Start a match
     */
    private void startMatch() {
        checking = true;
        var config = ArenaConfig.getInstance();
        int minPlayers = config.getMatchmakingMinPlayers();
        int maxPlayers = config.getMatchmakingMaxPlayers();

        List<class_3222> matchPlayers = new ArrayList<>();
        while (!queue.isEmpty() && matchPlayers.size() < maxPlayers) {
            class_3222 player = queue.poll();
            if (player != null && player.method_5805()) {
                matchPlayers.add(player);
            }
        }

        if (matchPlayers.size() >= minPlayers) {
            ArenaMod.LOGGER.info("PvP match started, players: {}", matchPlayers.size());

            for (class_3222 player : matchPlayers) {
                player.method_7353(class_2561.method_43469("message.arenamod.match_found", matchPlayers.size()).method_27692(class_124.field_1060), false);
            }

            GameManager.getInstance().startPVPGame(matchPlayers);
        } else {
            // Not enough players, put them back
            queue.addAll(matchPlayers);
            ArenaMod.LOGGER.info("PvP queue: not enough players, waiting");
        }

        checking = false;
    }

    public int getQueueSize() {
        return queue.size();
    }
}
