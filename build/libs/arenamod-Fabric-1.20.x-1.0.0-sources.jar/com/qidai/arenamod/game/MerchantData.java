package com.qidai.arenamod.game;

import com.qidai.arenamod.config.ArenaConfig;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1322;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_1847;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_5134;

/**
 * 竞技场商人数据：商品、价格、升级
 */
public class MerchantData {

    /** Upgrade costs are read from ArenaConfig (merchant.upgradeCostTier1 / tier2) */

    /** 商人类型常量 */
    public static final int MERCHANT_TYPE_ITEM = 0;
    public static final int MERCHANT_TYPE_BLOCK = 1;
    public static final int MERCHANT_TYPE_POTION = 2;

    public record MerchantItem(class_1799 item, int expCost, String category) {}

    // ========== 物品商人（原商人） ==========

    /** 一级商品 */
    public static final List<MerchantItem> TIER_1 = List.of(
            // 武器 (10 exp)
            new MerchantItem(new class_1799(class_1802.field_8091), 10, "weapon"),
            new MerchantItem(new class_1799(class_1802.field_8406), 10, "weapon"),
            new MerchantItem(new class_1799(class_1802.field_8102), 10, "weapon"),
            new MerchantItem(new class_1799(class_1802.field_8107, 16), 10, "weapon"),
            new MerchantItem(new class_1799(class_1802.field_8399), 10, "weapon"),
            new MerchantItem(new class_1799(class_1802.field_8255), 10, "weapon"),
            // 食物 (5 exp)
            new MerchantItem(new class_1799(class_1802.field_8179, 8), 5, "food"),
            new MerchantItem(new class_1799(class_1802.field_8279, 8), 5, "food"),
            new MerchantItem(new class_1799(class_1802.field_8741, 4), 5, "food"),
            new MerchantItem(new class_1799(class_1802.field_8497, 16), 5, "food"),
            new MerchantItem(new class_1799(class_1802.field_16998, 8), 5, "food"),
            new MerchantItem(new class_1799(class_1802.field_8635, 2), 5, "food"),
            new MerchantItem(new class_1799(class_1802.field_8511, 4), 5, "food"),
            new MerchantItem(new class_1799(class_1802.field_8176, 8), 5, "food"),
            new MerchantItem(new class_1799(class_1802.field_8347, 8), 5, "food"),
            new MerchantItem(new class_1799(class_1802.field_8544, 8), 5, "food"),
            // 防具 (15 exp) — 皮革套
            new MerchantItem(new class_1799(class_1802.field_8267), 15, "armor"),
            new MerchantItem(new class_1799(class_1802.field_8577), 15, "armor"),
            new MerchantItem(new class_1799(class_1802.field_8570), 15, "armor"),
            new MerchantItem(new class_1799(class_1802.field_8370), 15, "armor")
    );

    /** 二级商品 */
    public static final List<MerchantItem> TIER_2 = List.of(
            // 装备 (40 exp)
            new MerchantItem(new class_1799(class_1802.field_8743), 40, "armor"),
            new MerchantItem(new class_1799(class_1802.field_8523), 40, "armor"),
            new MerchantItem(new class_1799(class_1802.field_8396), 40, "armor"),
            new MerchantItem(new class_1799(class_1802.field_8660), 40, "armor"),
            // 工具 (25 exp)
            new MerchantItem(new class_1799(class_1802.field_8647), 25, "tool"),
            new MerchantItem(new class_1799(class_1802.field_8814, 8), 25, "tool"),
            // 食物 (25 exp)
            new MerchantItem(new class_1799(class_1802.field_8176, 8), 25, "food"),
            new MerchantItem(new class_1799(class_1802.field_8347, 8), 25, "food"),
            new MerchantItem(new class_1799(class_1802.field_8544, 8), 25, "food"),
            new MerchantItem(new class_1799(class_1802.field_8463, 2), 25, "food"),
            new MerchantItem(new class_1799(class_1802.field_8071, 8), 25, "food"),
            new MerchantItem(new class_1799(class_1802.field_8229, 16), 25, "food"),
            new MerchantItem(new class_1799(class_1802.field_8551, 16), 25, "food"),
            new MerchantItem(new class_1799(class_1802.field_17534), 25, "food"),
            new MerchantItem(new class_1799(class_1802.field_17519), 25, "food"),
            new MerchantItem(new class_1799(class_1802.field_8103), 25, "food")
    );

    /** 三级商品 */
    public static final List<MerchantItem> TIER_3 = List.of(
            // 装备 (50 exp)
            new MerchantItem(new class_1799(class_1802.field_8805), 50, "armor"),
            new MerchantItem(new class_1799(class_1802.field_8058), 50, "armor"),
            new MerchantItem(new class_1799(class_1802.field_8348), 50, "armor"),
            new MerchantItem(new class_1799(class_1802.field_8285), 50, "armor"),
            // 武器/箭矢 (40 exp)
            new MerchantItem(createTippedArrow(class_1847.field_8978, 8), 40, "weapon"),
            new MerchantItem(createTippedArrow(class_1847.field_9005, 8), 40, "weapon"),
            new MerchantItem(createTippedArrow(class_1847.field_8986, 8), 40, "weapon"),
            new MerchantItem(createTippedArrow(class_1847.field_8982, 8), 40, "weapon"),
            new MerchantItem(createTippedArrow(class_1847.field_8963, 8), 40, "weapon"),
            new MerchantItem(createTippedArrow(class_1847.field_8987, 8), 40, "weapon"),
            // 食物 (40 exp)
            new MerchantItem(new class_1799(class_1802.field_8367), 40, "food"),
            new MerchantItem(new class_1799(class_1802.field_8705), 40, "other"),
            // 通行证 (50 exp)
            new MerchantItem(createPass(), 50, "pass"),
            // 超级剑 (75 exp)
            new MerchantItem(createSuperSword(), 75, "weapon")
    );

    // ========== 方块商人 ==========

    /** 方块商人一级商品：各色羊毛、石头、圆石、草块、木头、煤块 (2 exp) */
    public static final List<MerchantItem> BLOCK_TIER_1 = List.of(
            new MerchantItem(new class_1799(class_1802.field_19044, 16), 2, "block"),
            new MerchantItem(new class_1799(class_1802.field_19045, 16), 2, "block"),
            new MerchantItem(new class_1799(class_1802.field_19047, 16), 2, "block"),
            new MerchantItem(new class_1799(class_1802.field_19058, 16), 2, "block"),
            new MerchantItem(new class_1799(class_1802.field_19049, 16), 2, "block"),
            new MerchantItem(new class_1799(class_1802.field_19055, 16), 2, "block"),
            new MerchantItem(new class_1799(class_1802.field_19059, 16), 2, "block"),
            new MerchantItem(new class_1799(class_1802.field_19051, 16), 2, "block"),
            new MerchantItem(new class_1799(class_1802.field_19050, 16), 2, "block"),
            new MerchantItem(new class_1799(class_1802.field_19053, 16), 2, "block"),
            new MerchantItem(new class_1799(class_1802.field_20391, 16), 2, "block"),
            new MerchantItem(new class_1799(class_1802.field_20412, 16), 2, "block"),
            new MerchantItem(new class_1799(class_1802.field_8270, 8), 2, "block"),
            new MerchantItem(new class_1799(class_1802.field_8583, 16), 2, "block"),
            new MerchantItem(new class_1799(class_1802.field_8797, 8), 2, "block")
    );

    /** 方块商人二级商品：铁块、金块、钻石块、下界合金块、黑曜石、绿宝石块、石英块 (10 exp) */
    public static final List<MerchantItem> BLOCK_TIER_2 = List.of(
            new MerchantItem(new class_1799(class_1802.field_8773, 8), 10, "block"),
            new MerchantItem(new class_1799(class_1802.field_8494, 8), 10, "block"),
            new MerchantItem(new class_1799(class_1802.field_8603, 8), 10, "block"),
            new MerchantItem(new class_1799(class_1802.field_22018, 4), 10, "block"),
            new MerchantItem(new class_1799(class_1802.field_8281, 8), 10, "block"),
            new MerchantItem(new class_1799(class_1802.field_8733, 8), 10, "block"),
            new MerchantItem(new class_1799(class_1802.field_20402, 8), 10, "block")
    );

    /** 方块商人三级商品：屏障、允许、边界、光源、水、流动岩浆 (25 exp) */
    public static final List<MerchantItem> BLOCK_TIER_3 = List.of(
            new MerchantItem(new class_1799(class_1802.field_8077), 25, "block"),
            new MerchantItem(new class_1799(class_1802.field_8615), 25, "block"),
            new MerchantItem(new class_1799(class_1802.field_8238), 25, "block"),
            new MerchantItem(new class_1799(class_1802.field_30904, 16), 25, "block"),
            new MerchantItem(new class_1799(class_1802.field_8705), 25, "block"),
            new MerchantItem(new class_1799(class_1802.field_8187), 25, "block")
    );

    // ========== 药水商人 ==========

    /** 药水商人一级：普通药水 I级 (25 exp) */
    public static final List<MerchantItem> POTION_TIER_1 = List.of(
            createPotionItem(class_1802.field_8574, class_1847.field_9005, "merchant.arenamod.potion.swiftness", 25),
            createPotionItem(class_1802.field_8574, class_1847.field_8978, "merchant.arenamod.potion.strength", 25),
            createPotionItem(class_1802.field_8574, class_1847.field_8963, "merchant.arenamod.potion.healing", 25),
            createPotionItem(class_1802.field_8574, class_1847.field_8986, "merchant.arenamod.potion.regeneration", 25),
            createPotionItem(class_1802.field_8574, class_1847.field_8987, "merchant.arenamod.potion.fire_resistance", 25),
            createPotionItem(class_1802.field_8574, class_1847.field_8994, "merchant.arenamod.potion.water_breathing", 25),
            createPotionItem(class_1802.field_8574, class_1847.field_8968, "merchant.arenamod.potion.night_vision", 25),
            createPotionItem(class_1802.field_8574, class_1847.field_8997, "merchant.arenamod.potion.invisibility", 25),
            createPotionItem(class_1802.field_8574, class_1847.field_8979, "merchant.arenamod.potion.leaping", 25),
            createPotionItem(class_1802.field_8574, class_1847.field_8982, "merchant.arenamod.potion.poison", 25),
            createPotionItem(class_1802.field_8574, class_1847.field_8974, "merchant.arenamod.potion.slow_falling", 25),
            createPotionItem(class_1802.field_8574, class_1847.field_8990, "merchant.arenamod.potion.turtle_master", 25)
    );

    /** 药水商人二级：喷溅药水 II级 (40 exp) */
    public static final List<MerchantItem> POTION_TIER_2 = List.of(
            createPotionItem(class_1802.field_8436, class_1847.field_8966, "merchant.arenamod.potion.t2.swiftness", 40),
            createPotionItem(class_1802.field_8436, class_1847.field_8993, "merchant.arenamod.potion.t2.strength", 40),
            createPotionItem(class_1802.field_8436, class_1847.field_8980, "merchant.arenamod.potion.t2.healing", 40),
            createPotionItem(class_1802.field_8436, class_1847.field_8992, "merchant.arenamod.potion.t2.regeneration", 40),
            createPotionItem(class_1802.field_8436, class_1847.field_8972, "merchant.arenamod.potion.t2.poison", 40),
            createPotionItem(class_1802.field_8436, class_1847.field_8998, "merchant.arenamod.potion.t2.leaping", 40),
            createPotionItem(class_1802.field_8436, class_1847.field_8977, "merchant.arenamod.potion.t2.turtle_master", 40),
            createPotionItem(class_1802.field_8436, class_1847.field_8974, "merchant.arenamod.potion.t2.slow_falling", 40),
            createPotionItem(class_1802.field_8436, class_1847.field_8987, "merchant.arenamod.potion.t2.fire_resistance", 40),
            createPotionItem(class_1802.field_8436, class_1847.field_8994, "merchant.arenamod.potion.t2.water_breathing", 40),
            createPotionItem(class_1802.field_8436, class_1847.field_8968, "merchant.arenamod.potion.t2.night_vision", 40),
            createPotionItem(class_1802.field_8436, class_1847.field_8997, "merchant.arenamod.potion.t2.invisibility", 40)
    );

    /** 药水商人三级：喷溅药水 X级 10分钟 (60 exp) */
    public static final List<MerchantItem> POTION_TIER_3 = List.of(
            createCustomSplashPotion(class_1294.field_5904, "merchant.arenamod.potion.t3.speed", 60),
            createCustomSplashPotion(class_1294.field_5910, "merchant.arenamod.potion.t3.strength", 60),
            createCustomSplashPotion(class_1294.field_5915, "merchant.arenamod.potion.t3.healing", 60),
            createCustomSplashPotion(class_1294.field_5924, "merchant.arenamod.potion.t3.regeneration", 60),
            createCustomSplashPotion(class_1294.field_5918, "merchant.arenamod.potion.t3.fire_resistance", 60),
            createCustomSplashPotion(class_1294.field_5923, "merchant.arenamod.potion.t3.water_breathing", 60),
            createCustomSplashPotion(class_1294.field_5925, "merchant.arenamod.potion.t3.night_vision", 60),
            createCustomSplashPotion(class_1294.field_5905, "merchant.arenamod.potion.t3.invisibility", 60),
            createCustomSplashPotion(class_1294.field_5913, "merchant.arenamod.potion.t3.leaping", 60),
            createCustomSplashPotion(class_1294.field_5899, "merchant.arenamod.potion.t3.poison", 60),
            createCustomSplashPotion(class_1294.field_5906, "merchant.arenamod.potion.t3.slow_falling", 60),
            createCustomSplashPotion(class_1294.field_5900, "merchant.arenamod.potion.t3.dolphins_grace", 60)
    );

    // ========== 统一查询接口 ==========

    /** 获取指定商人类型的商品列表 */
    public static List<MerchantItem> getItemsForMerchant(int merchantType, int tier) {
        return switch (merchantType) {
            case MERCHANT_TYPE_ITEM -> getItemsForTier(tier);
            case MERCHANT_TYPE_BLOCK -> getBlockItemsForTier(tier);
            case MERCHANT_TYPE_POTION -> getPotionItemsForTier(tier);
            default -> getItemsForTier(tier);
        };
    }

    /** 获取物品商人指定等级的商品 */
    public static List<MerchantItem> getItemsForTier(int tier) {
        return switch (tier) {
            case 1 -> TIER_1;
            case 2 -> TIER_2;
            case 3 -> TIER_3;
            default -> TIER_1;
        };
    }

    /** 获取方块商人指定等级的商品 */
    public static List<MerchantItem> getBlockItemsForTier(int tier) {
        return switch (tier) {
            case 1 -> BLOCK_TIER_1;
            case 2 -> BLOCK_TIER_2;
            case 3 -> BLOCK_TIER_3;
            default -> BLOCK_TIER_1;
        };
    }

    /** 获取药水商人指定等级的商品 */
    public static List<MerchantItem> getPotionItemsForTier(int tier) {
        return switch (tier) {
            case 1 -> POTION_TIER_1;
            case 2 -> POTION_TIER_2;
            case 3 -> POTION_TIER_3;
            default -> POTION_TIER_1;
        };
    }

    /** 获取商人名称（返回语言键） */
    public static String getMerchantName(int merchantType) {
        return switch (merchantType) {
            case MERCHANT_TYPE_ITEM -> "merchant.arenamod.merchant_name.item";
            case MERCHANT_TYPE_BLOCK -> "merchant.arenamod.merchant_name.block";
            case MERCHANT_TYPE_POTION -> "merchant.arenamod.merchant_name.potion";
            default -> "merchant.arenamod.merchant_name.item";
        };
    }

    /**
     * 获取从指定等级升级的费用（所有商人通用）
     */
    public static int getUpgradeCost(int currentTier) {
        var cfg = com.qidai.arenamod.config.ArenaConfig.getInstance();
        return switch (currentTier) {
            case 1 -> cfg.getMerchantUpgradeCostTier1();
            case 2 -> cfg.getMerchantUpgradeCostTier2();
            default -> Integer.MAX_VALUE;
        };
    }

    /** 获取分类显示名（返回语言键） */
    public static String getCategoryName(String category) {
        return switch (category) {
            case "weapon" -> "merchant.arenamod.category.weapon";
            case "food" -> "merchant.arenamod.category.food";
            case "armor" -> "merchant.arenamod.category.armor";
            case "tool" -> "merchant.arenamod.category.tool";
            case "pass" -> "merchant.arenamod.category.pass";
            case "other" -> "merchant.arenamod.category.other";
            case "block" -> "merchant.arenamod.category.block";
            case "potion" -> "merchant.arenamod.category.potion";
            default -> category;
        };
    }

    // ========== 辅助创建方法 ==========

    /**
     * 创建普通药水商品
     */
    private static MerchantItem createPotionItem(net.minecraft.class_1792 item, net.minecraft.class_1842 potion, String nameKey, int cost) {
        class_1799 stack = new class_1799(item);
        class_1844.method_8061(stack, potion);
        stack.method_7977(class_2561.method_43471(nameKey).method_27692(class_124.field_1075));
        return new MerchantItem(stack, cost, "potion");
    }

    /**
     * 创建自定义喷溅药水（三级：X级，10分钟）
     */
    private static MerchantItem createCustomSplashPotion(net.minecraft.class_1291 effect, String nameKey, int cost) {
        class_1799 stack = new class_1799(class_1802.field_8436);
        class_2487 nbt = stack.method_7948();
        class_2499 effects = new class_2499();

        int duration = 12000; // 10分钟 = 12000 ticks
        int amplifier = 9; // X级 = amplifier 9

        // 使用StatusEffectInstance自带的序列化，确保格式正确
        class_1293 instance;
        if (effect == class_1294.field_5915 || effect == class_1294.field_5921) {
            instance = new class_1293(effect, 1, amplifier);
        } else {
            instance = new class_1293(effect, duration, amplifier);
        }

        class_2487 effectData = new class_2487();
        instance.method_5582(effectData);
        effects.add(effectData);

        nbt.method_10566("CustomPotionEffects", effects);
        nbt.method_10582("Potion", "minecraft:water"); // 默认颜色
        stack.method_7977(class_2561.method_43471(nameKey).method_27695(class_124.field_1076, class_124.field_1067));
        return new MerchantItem(stack, cost, "potion");
    }

    /**
     * 创建超级剑：钻石剑材质，1000伤害，150耐久
     */
    private static class_1799 createSuperSword() {
        class_1799 stack = new class_1799(class_1802.field_8802);

        stack.method_7916(
                class_5134.field_23721,
                new class_1322(
                        UUID.fromString("cb3f55d3-645c-4f38-a497-9c13a33db5cf"),
                        "generic.attack_damage",
                        993.0,
                        class_1322.class_1323.field_6328
                ),
                class_1304.field_6173
        );

        stack.method_7974(stack.method_7936() - 150);
        stack.method_7977(class_2561.method_43471("merchant.arenamod.super_sword").method_27695(class_124.field_1065, class_124.field_1067));

        return stack;
    }

    /**
     * 创建药水箭
     */
    private static class_1799 createTippedArrow(net.minecraft.class_1842 potion, int count) {
        class_1799 stack = new class_1799(class_1802.field_8087, count);
        class_1844.method_8061(stack, potion);
        return stack;
    }

    /**
     * 创建一个通行证（允许携带一个物品离开竞技场）
     */
    public static class_1799 createPass() {
        class_1799 stack = new class_1799(class_1802.field_8407);
        stack.method_7977(class_2561.method_43471("merchant.arenamod.pass").method_27695(class_124.field_1060, class_124.field_1067));
        stack.method_7948().method_10556("ArenaPass", true);
        return stack;
    }

    /**
     * 判断物品是否为通行证（检查物品类型和 NBT 双重验证）
     */
    public static boolean isPassItem(class_1799 stack) {
        if (stack.method_7960()) return false;
        if (stack.method_7909() != class_1802.field_8407) return false;
        return stack.method_7969() != null && stack.method_7969().method_10545("ArenaPass");
    }
}
